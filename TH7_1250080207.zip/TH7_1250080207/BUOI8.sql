--Tạo bảng – QLBanHang 
CREATE TABLE HangSX ( 
    MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY, 
    TenHang VARCHAR2(30) NOT NULL, 
    DiaChi VARCHAR2(50), 
    SoDT VARCHAR2(15),
    Email VARCHAR2(50) 
); 

CREATE TABLE SanPham ( 
    MaSP VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY, 
    MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX), 
    TenSP VARCHAR2(50) NOT NULL, 
    SoLuong NUMBER(10), 
    MauSac VARCHAR2(20), 
    GiaBan NUMBER(15,2), 
    DonViTinh VARCHAR2(15), 
    MoTa CLOB 
); 

CREATE TABLE NhanVien ( 
    MaNV VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY, 
    TenNV VARCHAR2(50) NOT NULL, 
    GioiTinh VARCHAR2(10), 
    DiaChi VARCHAR2(100), 
    SoDT VARCHAR2(15), 
    Email VARCHAR2(50), 
    TenPhong VARCHAR2(30) 
); 

CREATE TABLE PNhap ( 
    SoHDN VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY, 
    NgayNhap DATE, 
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV) 
); 

CREATE TABLE Nhap ( 
    SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN), 
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP), 
    SoLuongN NUMBER(10), 
    DonGiaN NUMBER(15,2), 
    CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP) 
); 

CREATE TABLE PXuat ( 
    SoHDX VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY, 
    NgayXuat DATE, 
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV) 
); 

CREATE TABLE Xuat ( 
    SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX), 
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP), 
    SoLuongX NUMBER(10), 
    CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP) 
);


--PHIÊU BÀI TẬP 1
--a. Thủ tục sp_NhapHangSX
CREATE OR REPLACE PROCEDURE sp_NhapHangSX (
    p_MaHangSX IN VARCHAR2, p_TenHang IN VARCHAR2, 
    p_DiaChi IN VARCHAR2, p_SoDT IN VARCHAR2, p_Email IN VARCHAR2
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM HangSX WHERE TenHang = p_TenHang;
    
    IF v_dem > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten hang da ton tai!');
    ELSE
        INSERT INTO HangSX VALUES (p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Them hang SX thanh cong!');
    END IF;
END;
/


--b.Thủ tục sp_NhapSP 
CREATE OR REPLACE PROCEDURE sp_NhapSP (
    p_MaSP IN VARCHAR2, p_TenHang IN VARCHAR2, p_TenSP IN VARCHAR2, 
    p_SoLuong IN NUMBER, p_MauSac IN VARCHAR2, p_GiaBan IN NUMBER, 
    p_DonViTinh IN VARCHAR2, p_MoTa IN CLOB
) AS
    v_dem_hang NUMBER := 0;
    v_dem_sp NUMBER := 0;
    v_mahangsx VARCHAR2(10);
BEGIN
    --Kiem tra TenHang 
    SELECT COUNT(*) INTO v_dem_hang FROM HangSX WHERE TenHang = p_TenHang;
    IF v_dem_hang = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ten hang khong ton tai!');
        RETURN; -- Dừng thủ tục sớm
    END IF;

    -- Lấy MaHangSX tuong ung voi TenHang vao bien 
    SELECT MaHangSX INTO v_mahangsx FROM HangSX WHERE TenHang = p_TenHang;

    --Kiem tra MaSP 
    SELECT COUNT(*) INTO v_dem_sp FROM SanPham WHERE MaSP = p_MaSP;
    IF v_dem_sp > 0 THEN
        -- MaSP da ton tai -> UPDATE 
        UPDATE SanPham 
        SET MaHangSX = v_mahangsx, TenSP = p_TenSP, SoLuong = p_SoLuong, 
            MauSac = p_MauSac, GiaBan = p_GiaBan, DonViTinh = p_DonViTinh, MoTa = p_MoTa
        WHERE MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Cap nhat san pham thanh cong!');
    ELSE
        -- MaSP chua co -> INSERT 
        INSERT INTO SanPham VALUES (p_MaSP, v_mahangsx, p_TenSP, p_SoLuong, p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);
        DBMS_OUTPUT.PUT_LINE('Them moi san pham thanh cong!');
    END IF;
    COMMIT;
END;
/


--c. Thủ tục sp_xoaHangSX
CREATE OR REPLACE PROCEDURE sp_xoaHangSX (
    p_TenHang IN VARCHAR2
) AS
    v_dem NUMBER := 0;
    v_mahangsx VARCHAR2(10);
BEGIN
    SELECT COUNT(*) INTO v_dem FROM HangSX WHERE TenHang = p_TenHang;
    
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ten hang chua co!'); 
    ELSE
        -- Lấy mã hãng để xóa
        SELECT MaHangSX INTO v_mahangsx FROM HangSX WHERE TenHang = p_TenHang;
        
        -- Xóa bảng con trước 
        DELETE FROM SanPham WHERE MaHangSX = v_mahangsx;
        -- Xóa bảng cha sau 
        DELETE FROM HangSX WHERE MaHangSX = v_mahangsx;
        
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Xoa hang san xuat thanh cong!');
    END IF;
END;
/

--d. Thủ tục nhập NhanVien
CREATE OR REPLACE PROCEDURE sp_nhapNhanVien (
    p_MaNV IN VARCHAR2, p_TenNV IN VARCHAR2, p_GioiTinh IN VARCHAR2, 
    p_DiaChi IN VARCHAR2, p_SoDT IN VARCHAR2, p_Email IN VARCHAR2, 
    p_TenPhong IN VARCHAR2, p_Flag IN NUMBER 
) AS
BEGIN
    IF p_Flag = 0 THEN
        UPDATE NhanVien 
        SET TenNV = p_TenNV, GioiTinh = p_GioiTinh, DiaChi = p_DiaChi, 
            SoDT = p_SoDT, Email = p_Email, TenPhong = p_TenPhong
        WHERE MaNV = p_MaNV;
        DBMS_OUTPUT.PUT_LINE('Cap nhat nhan vien thanh cong!');
    ELSE
        INSERT INTO NhanVien VALUES (p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi, p_SoDT, p_Email, p_TenPhong); 
        DBMS_OUTPUT.PUT_LINE('Them nhan vien thanh cong!');
    END IF;
    COMMIT;
END;
/



--e. Thủ tục nhập dữ liệu bảng Nhap
CREATE OR REPLACE PROCEDURE sp_nhapBangNhap (
    p_SoHDN IN VARCHAR2, p_MaSP IN VARCHAR2, p_MaNV IN VARCHAR2,
    p_NgayNhap IN DATE, p_SoLuongN IN NUMBER, p_DonGiaN IN NUMBER
) AS
    v_dem_sp NUMBER := 0;
    v_dem_nv NUMBER := 0;
    v_dem_hdn NUMBER := 0;
BEGIN
    -- Kiểm tra MaSP
    SELECT COUNT(*) INTO v_dem_sp FROM SanPham WHERE MaSP = p_MaSP;
    IF v_dem_sp = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma san pham khong ton tai!');
        RETURN; 
    END IF;

    -- Kiểm tra MaNV
    SELECT COUNT(*) INTO v_dem_nv FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_dem_nv = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma nhan vien khong ton tai!');
        RETURN;
    END IF;

    -- Kiểm tra SoHDN đã tồn tại chưa
    SELECT COUNT(*) INTO v_dem_hdn FROM PNhap WHERE SoHDN = p_SoHDN;
    IF v_dem_hdn > 0 THEN
        UPDATE Nhap SET SoLuongN = p_SoLuongN, DonGiaN = p_DonGiaN 
        WHERE SoHDN = p_SoHDN AND MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Cap nhat bang Nhap thanh cong!');
    ELSE
        INSERT INTO PNhap(SoHDN, NgayNhap, MaNV) VALUES (p_SoHDN, p_NgayNhap, p_MaNV);
        INSERT INTO Nhap(SoHDN, MaSP, SoLuongN, DonGiaN) VALUES (p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);
        DBMS_OUTPUT.PUT_LINE('Them moi Phieu Nhap va chi tiet Nhap thanh cong!');
    END IF;
    COMMIT;
END;
/


--f. Thủ tục nhập dữ liệu bảng Xuat
CREATE OR REPLACE PROCEDURE sp_nhapBangXuat (
    p_SoHDX IN VARCHAR2, p_MaSP IN VARCHAR2, p_MaNV IN VARCHAR2,
    p_NgayXuat IN DATE, p_SoLuongX IN NUMBER
) AS
    v_dem_sp NUMBER := 0;
    v_dem_nv NUMBER := 0;
    v_dem_hdx NUMBER := 0;
    v_soluong_ton NUMBER := 0;
BEGIN
    -- Kiểm tra MaSP
    SELECT COUNT(*) INTO v_dem_sp FROM SanPham WHERE MaSP = p_MaSP;
    IF v_dem_sp = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma san pham khong ton tai!');
        RETURN;
    END IF;

    -- Kiểm tra MaNV
    SELECT COUNT(*) INTO v_dem_nv FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_dem_nv = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma nhan vien khong ton tai!');
        RETURN;
    END IF;

    -- Lấy số lượng tồn kho và so sánh
    SELECT SoLuong INTO v_soluong_ton FROM SanPham WHERE MaSP = p_MaSP;
    IF p_SoLuongX > v_soluong_ton THEN
        DBMS_OUTPUT.PUT_LINE('Loi: So luong xuat vuot qua so luong ton kho!');
        RETURN;
    END IF;

    -- Kiểm tra SoHDX đã tồn tại chưa
    SELECT COUNT(*) INTO v_dem_hdx FROM PXuat WHERE SoHDX = p_SoHDX;
    IF v_dem_hdx > 0 THEN
        UPDATE Xuat SET SoLuongX = p_SoLuongX WHERE SoHDX = p_SoHDX AND MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Cap nhat bang Xuat thanh cong!');
    ELSE
        INSERT INTO PXuat(SoHDX, NgayXuat, MaNV) VALUES (p_SoHDX, p_NgayXuat, p_MaNV);
        INSERT INTO Xuat(SoHDX, MaSP, SoLuongX) VALUES (p_SoHDX, p_MaSP, p_SoLuongX);
        DBMS_OUTPUT.PUT_LINE('Them moi Phieu Xuat va chi tiet Xuat thanh cong!');
    END IF;
    COMMIT;
END;
/


--g. Thủ tục xóa NhanVien
CREATE OR REPLACE PROCEDURE sp_xoaNhanVien (
    p_MaNV IN VARCHAR2
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM NhanVien WHERE MaNV = p_MaNV;
    
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma nhan vien chua co!');
    ELSE
        DELETE FROM Nhap WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = p_MaNV);
        DELETE FROM Xuat WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = p_MaNV);
        DELETE FROM PNhap WHERE MaNV = p_MaNV;
        DELETE FROM PXuat WHERE MaNV = p_MaNV;
        DELETE FROM NhanVien WHERE MaNV = p_MaNV;
        
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Xoa nhan vien va cac du lieu lien quan thanh cong!');
    END IF;
END;
/


--h. Thủ tục xóa SanPham
CREATE OR REPLACE PROCEDURE sp_xoaSanPham (
    p_MaSP IN VARCHAR2
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM SanPham WHERE MaSP = p_MaSP;
    
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma san pham chua co!');
    ELSE
        DELETE FROM Nhap WHERE MaSP = p_MaSP;
        DELETE FROM Xuat WHERE MaSP = p_MaSP;
        DELETE FROM SanPham WHERE MaSP = p_MaSP;
        
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Xoa san pham va du lieu lien quan thanh cong!');
    END IF;
END;
/


--PHIẾU BÀI TẬP 2
--a. Thủ tục sp_ThemNhanVien (có OUT)
CREATE OR REPLACE PROCEDURE sp_ThemNhanVien (
    p_MaNV IN VARCHAR2, p_TenNV IN VARCHAR2, p_GioiTinh IN VARCHAR2, 
    p_DiaChi IN VARCHAR2, p_SoDT IN VARCHAR2, p_Email IN VARCHAR2, 
    p_TenPhong IN VARCHAR2, p_Flag IN NUMBER, 
    p_KQ OUT NUMBER -- Tham số OUT trả về mã lỗi 
) AS 
BEGIN
    -- Kiểm tra giới tính hợp lệ 
    IF p_GioiTinh <> 'Nam' AND p_GioiTinh <> 'Nữ' THEN 
        p_KQ := 1; 
        RETURN; 
    END IF;

    -- Kiểm tra Flag để Insert hoặc Update
    IF p_Flag = 0 THEN 
        INSERT INTO NhanVien VALUES (p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi, p_SoDT, p_Email, p_TenPhong); 
    ELSE 
        UPDATE NhanVien SET TenNV = p_TenNV, GioiTinh = p_GioiTinh, DiaChi = p_DiaChi, 
                            SoDT = p_SoDT, Email = p_Email, TenPhong = p_TenPhong
        WHERE MaNV = p_MaNV; 
    END IF;
    
    COMMIT;
    p_KQ := 0;
END;
/


--b. Thủ tục sp_ThemMoiSP (có OUT)
CREATE OR REPLACE PROCEDURE sp_ThemMoiSP (
    p_MaSP IN VARCHAR2, p_TenHang IN VARCHAR2, p_TenSP IN VARCHAR2, 
    p_SoLuong IN NUMBER, p_MauSac IN VARCHAR2, p_GiaBan IN NUMBER, 
    p_DonViTinh IN VARCHAR2, p_MoTa IN CLOB, p_Flag IN NUMBER, 
    p_KQ OUT NUMBER
) AS
    v_dem_hang NUMBER := 0;
    v_mahangsx VARCHAR2(10);
BEGIN
    -- TenHang không có trong HangSX -> trả về 1 
    SELECT COUNT(*) INTO v_dem_hang FROM HangSX WHERE TenHang = p_TenHang;
    IF v_dem_hang = 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;

    -- SoLuong < 0 -> trả về 2 
    IF p_SoLuong < 0 THEN
        p_KQ := 2;
        RETURN;
    END IF;

    -- Lấy MaHangSX 
    SELECT MaHangSX INTO v_mahangsx FROM HangSX WHERE TenHang = p_TenHang;

    -- Flag = 0 -> INSERT. Flag ≠ 0 -> UPDATE 
    IF p_Flag = 0 THEN
        INSERT INTO SanPham VALUES (p_MaSP, v_mahangsx, p_TenSP, p_SoLuong, p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);
    ELSE
        UPDATE SanPham SET MaHangSX = v_mahangsx, TenSP = p_TenSP, SoLuong = p_SoLuong, 
                           MauSac = p_MauSac, GiaBan = p_GiaBan, DonViTinh = p_DonViTinh, MoTa = p_MoTa
        WHERE MaSP = p_MaSP;
    END IF;
    COMMIT;
    p_KQ := 0; 
END;
/

--c. Thủ tục xóa NhanVien (có OUT)
CREATE OR REPLACE PROCEDURE sp_xoaNhanVien_Out (
    p_MaNV IN VARCHAR2, p_KQ OUT NUMBER 
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM NhanVien WHERE MaNV = p_MaNV;

    IF v_dem = 0 THEN
        p_KQ := 1; 
    ELSE
        DELETE FROM Nhap WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = p_MaNV);
        DELETE FROM Xuat WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = p_MaNV);
        DELETE FROM PNhap WHERE MaNV = p_MaNV;
        DELETE FROM PXuat WHERE MaNV = p_MaNV;
        DELETE FROM NhanVien WHERE MaNV = p_MaNV;
        COMMIT;
        p_KQ := 0; 
    END IF;
END;
/

--d. Thủ tục xóa SanPham (có OUT)
CREATE OR REPLACE PROCEDURE sp_xoaSanPham_Out (
    p_MaSP IN VARCHAR2, p_KQ OUT NUMBER 
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM SanPham WHERE MaSP = p_MaSP;

    IF v_dem = 0 THEN
        p_KQ := 1;
    ELSE
        DELETE FROM Nhap WHERE MaSP = p_MaSP;
        DELETE FROM Xuat WHERE MaSP = p_MaSP;
        DELETE FROM SanPham WHERE MaSP = p_MaSP;
        COMMIT;
        p_KQ := 0;
    END IF;
END;
/

--e. Thủ tục sp_NhapHangSX (có OUT)
CREATE OR REPLACE PROCEDURE sp_NhapHangSX_Out (
    p_MaHangSX IN VARCHAR2, p_TenHang IN VARCHAR2, p_DiaChi IN VARCHAR2, 
    p_SoDT IN VARCHAR2, p_Email IN VARCHAR2, p_KQ OUT NUMBER 
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM HangSX WHERE TenHang = p_TenHang;

    IF v_dem > 0 THEN
        p_KQ := 1; 
    ELSE
        INSERT INTO HangSX VALUES (p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);
        COMMIT;
        p_KQ := 0; 
    END IF;
END;
/

--f. Thủ tục nhập bảng Nhap (có OUT)
CREATE OR REPLACE PROCEDURE sp_nhapBangNhap_Out (
    p_SoHDN IN VARCHAR2, p_MaSP IN VARCHAR2, p_MaNV IN VARCHAR2,
    p_NgayNhap IN DATE, p_SoLuongN IN NUMBER, p_DonGiaN IN NUMBER, 
    p_KQ OUT NUMBER 
) AS
    v_dem_sp NUMBER := 0;
    v_dem_nv NUMBER := 0;
    v_dem_hdn NUMBER := 0;
BEGIN
    -- MaSP không có trong SanPham -> trả về 1 
    SELECT COUNT(*) INTO v_dem_sp FROM SanPham WHERE MaSP = p_MaSP;
    IF v_dem_sp = 0 THEN p_KQ := 1; RETURN; END IF;

    -- MaNV không có trong NhanVien -> trả về 2 
    SELECT COUNT(*) INTO v_dem_nv FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_dem_nv = 0 THEN p_KQ := 2; RETURN; END IF;

    -- SoHDN tồn tại -> UPDATE. Chưa tồn tại -> INSERT 
    SELECT COUNT(*) INTO v_dem_hdn FROM PNhap WHERE SoHDN = p_SoHDN;
    IF v_dem_hdn > 0 THEN
        UPDATE Nhap SET SoLuongN = p_SoLuongN, DonGiaN = p_DonGiaN WHERE SoHDN = p_SoHDN AND MaSP = p_MaSP;
    ELSE
        INSERT INTO PNhap(SoHDN, NgayNhap, MaNV) VALUES (p_SoHDN, p_NgayNhap, p_MaNV);
        INSERT INTO Nhap(SoHDN, MaSP, SoLuongN, DonGiaN) VALUES (p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);
    END IF;
    
    COMMIT;
    p_KQ := 0; 
END;
/

--g. Thủ tục nhập bảng Xuat (có OUT)
CREATE OR REPLACE PROCEDURE sp_nhapBangXuat_Out (
    p_SoHDX IN VARCHAR2, p_MaSP IN VARCHAR2, p_MaNV IN VARCHAR2,
    p_NgayXuat IN DATE, p_SoLuongX IN NUMBER, 
    p_KQ OUT NUMBER 
) AS
    v_dem_sp NUMBER := 0;
    v_dem_nv NUMBER := 0;
    v_soluong_ton NUMBER := 0;
    v_dem_hdx NUMBER := 0;
BEGIN
    -- MaSP không có trong SanPham -> trả về 1 
    SELECT COUNT(*) INTO v_dem_sp FROM SanPham WHERE MaSP = p_MaSP;
    IF v_dem_sp = 0 THEN p_KQ := 1; RETURN; END IF;

    -- MaNV không có trong NhanVien -> trả về 2 
    SELECT COUNT(*) INTO v_dem_nv FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_dem_nv = 0 THEN p_KQ := 2; RETURN; END IF;

    -- SoLuongX > SoLuong trong SanPham -> trả về 3 
    SELECT SoLuong INTO v_soluong_ton FROM SanPham WHERE MaSP = p_MaSP;
    IF p_SoLuongX > v_soluong_ton THEN p_KQ := 3; RETURN; END IF;

    -- SoHDX tồn tại -> UPDATE. Chưa tồn tại -> INSERT 
    SELECT COUNT(*) INTO v_dem_hdx FROM PXuat WHERE SoHDX = p_SoHDX;
    IF v_dem_hdx > 0 THEN
        UPDATE Xuat SET SoLuongX = p_SoLuongX WHERE SoHDX = p_SoHDX AND MaSP = p_MaSP;
    ELSE
        INSERT INTO PXuat(SoHDX, NgayXuat, MaNV) VALUES (p_SoHDX, p_NgayXuat, p_MaNV);
        INSERT INTO Xuat(SoHDX, MaSP, SoLuongX) VALUES (p_SoHDX, p_MaSP, p_SoLuongX);
    END IF;
    
    COMMIT;
    p_KQ := 0; 
END;
/