--Tạo bảng dữ liệu 
CREATE TABLE SANPHAM (
    MASP VARCHAR2(20) PRIMARY KEY,
    TENSP VARCHAR2(100),      
    XUATXU VARCHAR2(50),         
    GIABAN NUMBER
);

CREATE TABLE KHACHHANG (
    MAKH VARCHAR2(20) PRIMARY KEY,
    TENKH VARCHAR2(100),
    SDT VARCHAR2(15), 
    EMAIL VARCHAR2(100),        
    DIACHI VARCHAR2(200)
); 

CREATE TABLE HOADON (
    MAHD VARCHAR2(20) PRIMARY KEY,
    NGAYTAO DATE,
    MAKH VARCHAR2(20),         
    TONGTIEN NUMBER,          
    TRANGTHAI VARCHAR2(50)
);

--Xoá bảng 
DROP TABLE SANPHAM;
DROP TABLE KHACHHANG; 
DROP TABLE HOADON;

--Chèn dữ liệu bảng SANPHAM 
INSERT INTO SANPHAM VALUES ('SP01', 'Laptop Asus Gaming', 'Đài Loan', 25000000);
INSERT INTO SANPHAM VALUES ('SP02', 'Iphone 13 Pro Max', 'Việt Nam', 18500000);
INSERT INTO SANPHAM VALUES ('SP03', 'Tai nghe Sony', 'Nhật Bản', 1200000);
COMMIT;

--Chèn dữ liệu bảng KHACHHANG 
INSERT INTO KHACHHANG VALUES ('KH01', 'Kim Mẫn Khuê', '0909123456', 'kmk0604@gmail.com', 'Quận 1, TP.HCM');
INSERT INTO KHACHHANG VALUES ('KH02', 'Lâm Tâm Như', '0918888999', 'ltamnhu@gmail.com', 'Cầu Giấy, Hà Nội');
INSERT INTO KHACHHANG VALUES ('KH03', 'Nguyễn Phương Nhi', '0987654321', 'phuongnhi2000@gmail.com', 'Hải Châu, Đà Nẵng');

--Chèn dữ liệu bảng HOADON
INSERT INTO HOADON VALUES ('HD01', '30/12/2025', 'KH01', 25000000, 'Đã thanh toán');
INSERT INTO HOADON VALUES ('HD02', '01/01/2026', 'KH02', 18500000, 'Chờ giao hàng');
INSERT INTO HOADON VALUES ('HD03', '04/01/2026', 'KH01', 1200000, 'Đã hủy');

SELECT * FROM SANPHAM;
SELECT * FROM KHACHHANG;
SELECT * FROM HOADON;

-- Cho phép doantinhhan được xem và thêm dữ liệu vào các bảng 
GRANT SELECT, INSERT ON SANPHAM TO doantinhhan;
GRANT SELECT, INSERT ON KHACHHANG TO doantinhhan;
GRANT SELECT, INSERT ON HOADON TO doantinhhan;

-- Cho phép doantinhhan  được sửa và xoá khách hàng 
GRANT UPDATE, DELETE ON SANPHAM TO doantinhhan;
GRANT UPDATE, DELETE ON KHACHHANG TO doantinhhan;
GRANT UPDATE, DELETE ON HOADON TO doantinhhan;

--Xem các bảng SANPHAM, KHACHHANG, HOADON của doantinhhan 
SELECT * FROM doantinhhan.NHANVIEN;
SELECT * FROM doantinhhan.DUAN;
SELECT * FROM doantinhhan.LUONG;

--Thêm một nhân viên mới = vào bảng NHANVIEN 
INSERT INTO doantinhhan.NHANVIEN VALUES ('NV04', 'Trần Kiện Phong', '23/04/1995', 0967054805, 'Project Manager' );
COMMIT;

--Xoá dữ liệu bảng LUONG của doantinhhan 
DELETE FROM doantinhhan.LUONG;

--Sửa tên 1 khách hàng của bảng DUAN 
UPDATE doantinhhan.DUAN SET KHACHHANG = 'Viettinbank' WHERE MADA = 'DA01';
COMMIT;
