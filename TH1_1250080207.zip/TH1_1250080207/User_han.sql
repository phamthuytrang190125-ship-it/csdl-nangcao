-- Tạo bảng 
CREATE TABLE NHANVIEN (
    MANV VARCHAR2(20) PRIMARY KEY,
    TENNV VARCHAR2(100),
    NGAYSINH DATE,             
    SDT VARCHAR2(15), 
    CHUYENMON VARCHAR2(50) 
);

CREATE TABLE DUAN (
    MADA VARCHAR2(20) PRIMARY KEY,
    TENDA VARCHAR2(100),
    NGAYBATDAU DATE,
    NGAYKETTHUC DATE,         
    KINHPHI NUMBER,            
    KHACHHANG VARCHAR2(100)
);
DROP TABLE DUAN;

CREATE TABLE LUONG (
    BACLUONG NUMBER PRIMARY KEY, 
    TIENLUONG NUMBER,            
    PHUCAP NUMBER,       
    TIENTHUONG NUMBER   
);

--Thêm dữ liệu cho bảng NHAVIEN 
INSERT INTO NHANVIEN VALUES ('NV01', 'Hồ Định Hân', '15/05/2000', '0909154805', 'Tester');
INSERT INTO NHANVIEN VALUES ('NV02', 'Trần Triển Bằng', '20/11/1998', '0913809419', 'Developer');
INSERT INTO NHANVIEN VALUES ('NV03', 'Lưu Bội Nguyệt', '10/03/2005', '0988932837', 'Business Analyst');

--Thêm dữ liệu cho bảng DUAN
INSERT INTO DUAN VALUES ('DA01', 'App Ngân Hàng', '01/01/2026', '30/06/2026', 500000000, 'MB Bank');
INSERT INTO DUAN VALUES ('DA02', 'Web Thương Mại Điện Tử', '05/01/2026', '15/12/2026', 200000000, 'Shopify VN');
INSERT INTO DUAN VALUES ('DA03', 'AI Chatbot', '03/01/2026', '01/12/2026', 1000000000, 'FPT Software');

--Thêm dữ liệu cho bảng LUONG 
INSERT INTO LUONG VALUES (1, 8000000, 1000000, 500000);
INSERT INTO LUONG VALUES (2, 15000000, 1500000, 2000000);
INSERT INTO LUONG VALUES (3, 30000000, 2000000, 5000000);

SELECT * FROM NHANVIEN;
SELECT * FROM DUAN;
SELECT * FROM LUONG;

-- Cho phép phamthithuytrang được xem và thêm dữ liệu vào các bảng
GRANT SELECT, INSERT ON NHANVIEN TO phamthithuytrang;
GRANT SELECT, INSERT ON DUAN TO phamthithuytrang;
GRANT SELECT, INSERT ON LUONG TO phamthithuytrang;

-- Cho phép phamthithuytrang  được sửa và xoá các bảng 
GRANT UPDATE, DELETE ON NHANVIEN TO phamthithuytrang;
GRANT UPDATE, DELETE ON DUAN TO phamthithuytrang;
GRANT UPDATE, DELETE ON LUONG TO phamthithuytrang;

--Xem các bảng SANPHAM, KHACHHANG, HOADON của phamthithuytrang 
SELECT * FROM phamthithuytrang.SANPHAM;
SELECT * FROM phamthithuytrang.KHACHHANG;
SELECT * FROM phamthithuytrang.HOADON;

--Thêm một SANPHAM vào bảng của phamthithuytrang 
INSERT INTO phamthithuytrang.SANPHAM VALUES ('SP04', 'Samsung S24', 'Hàn Quốc', 20000000);
COMMIT;

--Xoá dữ liệu bảng HOADON của phamthithuytrang 
DELETE FROM phamthithuytrang.HOADON;

--Sửa tên 1 khách hàng của phamthithuytrang 
UPDATE phamthithuytrang.KHACHHANG SET TENKH = 'Văn Tuấn Huy' WHERE MAKH = 'KH01';
COMMIT;