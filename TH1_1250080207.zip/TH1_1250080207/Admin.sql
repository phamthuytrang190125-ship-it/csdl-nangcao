-- Cho phép tạo user dễ dàng
ALTER SESSION SET "_ORACLE_SCRIPT"=true;

-- 1. Tạo user is01 
CREATE USER phamthithuytrang IDENTIFIED BY 123456;
GRANT CONNECT, RESOURCE TO phamthithuytrang;
ALTER USER phamthithuytrang QUOTA UNLIMITED ON USERS; 

-- 2. Tạo user is02 
CREATE USER doantinhhan IDENTIFIED BY 123456;
GRANT CONNECT, RESOURCE TO doantinhhan;
ALTER USER doantinhhan QUOTA UNLIMITED  ON USERS;


SHOW CON_NAME;

-- Xem user vừa tạo
SELECT username, account_status 
FROM dba_users
WHERE username IN ('PHAMTHITHUYTRANG', 'DOANTINHHAN');