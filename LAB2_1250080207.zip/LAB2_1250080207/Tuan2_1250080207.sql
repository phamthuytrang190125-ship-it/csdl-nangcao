-- 1. Tạo bảng
CREATE TABLE regions (
    region_id NUMBER PRIMARY KEY, 
    region_name VARCHAR2(25)
);

CREATE TABLE countries (
    country_id CHAR(2) PRIMARY KEY, 
    country_name VARCHAR2(40), 
    region_id NUMBER REFERENCES regions(region_id)
);

CREATE TABLE locations (
    location_id NUMBER(4) PRIMARY KEY, 
    street_address VARCHAR2(40), 
    city VARCHAR2(30), 
    state_province VARCHAR2(25), 
    postal_code VARCHAR2(12), 
    country_id CHAR(2) REFERENCES countries(country_id)
);

CREATE TABLE jobs (
    job_id VARCHAR2(10) PRIMARY KEY, 
    job_title VARCHAR2(35), 
    min_salary NUMBER(6), 
    max_salary NUMBER(6)
);

CREATE TABLE departments (
    department_id NUMBER(4) PRIMARY KEY, 
    department_name VARCHAR2(30), 
    manager_id NUMBER(6), 
    location_id NUMBER(4) REFERENCES locations(location_id)
);

CREATE TABLE employees (
    employee_id NUMBER(6) PRIMARY KEY, 
    last_name VARCHAR2(25), 
    first_name VARCHAR2(20), 
    email VARCHAR2(25), 
    hire_date DATE, 
    job_id VARCHAR2(10) REFERENCES jobs(job_id), 
    salary NUMBER(8,2), 
    commission_pct NUMBER(2,2), 
    manager_id NUMBER(6) REFERENCES employees(employee_id), 
    department_id NUMBER(4) REFERENCES departments(department_id)
);

ALTER TABLE departments ADD CONSTRAINT dept_mgr_fk FOREIGN KEY (manager_id) REFERENCES employees(employee_id);

CREATE TABLE job_history (
    employee_id NUMBER(6) REFERENCES employees(employee_id), 
    start_date DATE, 
    end_date DATE, 
    job_id VARCHAR2(10) REFERENCES jobs(job_id), 
    department_id NUMBER(4) REFERENCES departments(department_id), 
    PRIMARY KEY (employee_id, start_date)
);

SELECT table_name FROM user_tables;

-- 2. Chèn dữ liệu 
INSERT INTO regions VALUES (1, 'Europe');
INSERT INTO regions VALUES (2, 'Americas');

INSERT INTO countries VALUES ('US', 'United States of America', 2);
INSERT INTO countries VALUES ('CA', 'Canada', 2);

INSERT INTO locations VALUES (1500, '2011 Interiors Blvd', 'South San Francisco', 'California', '99236', 'US');
INSERT INTO locations VALUES (1700, '2004 Charade Rd', 'Seattle', 'Washington', '98199', 'US');
INSERT INTO locations VALUES (1800, '147 Spadina Ave', 'Toronto', 'Ontario', 'M5V 2L7', 'CA');

INSERT INTO jobs VALUES ('AD_PRES', 'President', 20000, 40000);
INSERT INTO jobs VALUES ('ST_MAN', 'Stock Manager', 5500, 8500);
INSERT INTO jobs VALUES ('IT_PROG', 'Programmer', 4000, 10000);
INSERT INTO jobs VALUES ('SA_REP', 'Sales Representative', 6000, 12000);
INSERT INTO jobs VALUES ('ST_CLERK', 'Stock Clerk', 2000, 5000);

INSERT INTO departments VALUES (10, 'Administration', NULL, 1700);
INSERT INTO departments VALUES (20, 'Marketing', NULL, 1800);
INSERT INTO departments VALUES (50, 'Shipping', NULL, 1500);
INSERT INTO departments VALUES (60, 'IT', NULL, 1700);
INSERT INTO departments VALUES (80, 'Sales', NULL, 1700);
INSERT INTO departments VALUES (90, 'Executive', NULL, 1700);
INSERT INTO departments VALUES (500, 'New Dept', NULL, 1700); 

INSERT INTO employees VALUES (100, 'King', 'Steven', 'SKING', TO_DATE('17/06/1987', 'DD/MM/YYYY'), 'AD_PRES', 24000, NULL, NULL, 90);
INSERT INTO employees VALUES (101, 'Kochhar', 'Neena', 'NKOCHHAR', TO_DATE('21/09/1989', 'DD/MM/YYYY'), 'AD_PRES', 17000, NULL, 100, 90);
INSERT INTO employees VALUES (3, 'Name', 'Old', 'ONAME', TO_DATE('01/01/1990', 'DD/MM/YYYY'), 'IT_PROG', 4000, NULL, 100, 60);
INSERT INTO employees VALUES (145, 'Russell', 'John', 'JRUSSEL', TO_DATE('01/10/1996', 'DD/MM/YYYY'), 'SA_REP', 14000, .4, 100, 80);
INSERT INTO employees VALUES (149, 'Zlotkey', 'Eleni', 'EZLOTKEY', TO_DATE('29/01/1996', 'DD/MM/YYYY'), 'SA_REP', 10500, .2, 100, 80);
INSERT INTO employees VALUES (151, 'Bernstein', 'David', 'DBERNSTE', TO_DATE('24/03/1998', 'DD/MM/YYYY'), 'SA_REP', 9500, .25, 145, 80);
INSERT INTO employees VALUES (105, 'Austin', 'David', 'DAUSTIN', TO_DATE('25/06/1997', 'DD/MM/YYYY'), 'IT_PROG', 4800, NULL, 103, 60); 
INSERT INTO employees VALUES (107, 'Lorentz', 'Diana', 'DLORENTZ', TO_DATE('07/02/1994', 'DD/MM/YYYY'), 'IT_PROG', 4200, NULL, 103, 60);
INSERT INTO employees VALUES (124, 'Mourgos', 'Kevin', 'KMOURGOS', TO_DATE('16/11/1999', 'DD/MM/YYYY'), 'ST_MAN', 5800, NULL, 100, 50); 
INSERT INTO employees VALUES (142, 'Davies', 'Curtis', 'CDAVIES', TO_DATE('29/01/1997', 'DD/MM/YYYY'), 'ST_CLERK', 3100, NULL, 124, 50);
INSERT INTO employees VALUES (201, 'Hartstein', 'Michael', 'MHARTSTE', TO_DATE('17/02/1996', 'DD/MM/YYYY'), 'ST_MAN', 13000, NULL, 100, 20); 
INSERT INTO employees VALUES (137, 'Kramer', 'John', 'JKRAMER', TO_DATE('01/01/1994', 'DD/MM/YYYY'), 'ST_CLERK', 800, NULL, 124, 50);
INSERT INTO employees VALUES (207, 'Jones', 'Jack', 'JJONES', TO_DATE('01/01/1994', 'DD/MM/YYYY'), 'ST_CLERK', 850, NULL, 100, 10);
SELECT * FROM  employees;
COMMIT;


UPDATE departments SET manager_id = 100 WHERE department_id = 90;
UPDATE departments SET manager_id = 201 WHERE department_id = 20;
UPDATE departments SET manager_id = 124 WHERE department_id = 50;
UPDATE departments SET manager_id = 149 WHERE department_id = 80;

COMMIT;

--PHẦN 2: 
--NHÓM 1: SELECT Và WHERE - Lọc Dữ Liệu Cơ Bản (Câu 1–10)

--1. Liệt kê tên (last_name) và lương (salary) của những nhân viên có lương lớn hơn 12000$.
SELECT last_name, salary
FROM   employees
WHERE  salary > 12000;

--2. Liệt kê tên và lương của những nhân viên có lương thấp hơn 5000$ hoặc lớn hơn 12000$.
--cach1:
SELECT last_name, salary
FROM   employees
WHERE  salary < 5000 OR salary > 12000;

--cach2:
SELECT last_name, salary    
FROM   employees
WHERE  salary NOT BETWEEN 5000 AND 12000;

--3. Cho biết thông tin tên nhân viên (last_name), mã công việc (job_id), 
--ngày thuê (hire_date) của những nhân viên được thuê từ ngày 20/02/1998 đến ngày 1/05/1998. 
--Thông tin được hiển thị tăng dần theo ngày thuê.
SELECT last_name, job_id, hire_date
FROM   employees
WHERE  hire_date BETWEEN TO_DATE('20/02/1998','DD/MM/YYYY')
                     AND TO_DATE('01/05/1998','DD/MM/YYYY')
ORDER BY hire_date ASC;

--4. Liệt kê danh sách nhân viên làm việc cho phòng 20 và 50. 
--Thông tin hiển thị gồm: last_name, department_id , trong đó tên nhân viên được sắp xếp theo thứ tự alphabe.
SELECT last_name, department_id
FROM   employees
WHERE  department_id IN (20, 50)
ORDER BY last_name ASC;

--5. Liệt kê danh sách nhân viên được thuê năm 1994. 
--cach1:
SELECT last_name, hire_date
FROM   employees
WHERE  TO_CHAR(hire_date, 'YYYY') = '1994';

--cach2:
SELECT last_name, hire_date
FROM   employees
WHERE  hire_date BETWEEN TO_DATE('01/01/1994','DD/MM/YYYY')
                     AND TO_DATE('31/12/1994','DD/MM/YYYY');

--6. Liệt kê tên nhân viên (last_name), mã công việc (job_id) của những nhân viên không có người quản lý.
SELECT last_name, job_id
FROM   employees
WHERE  manager_id IS NULL;

--7. Cho biết thông tin tất cả nhân viên được hưởng hoa hồng(commission_pct), 
--kết quả được sắp xếp giảm dần theo lương và hoa hồng.
SELECT last_name, salary, commission_pct
FROM   employees
WHERE  commission_pct IS NOT NULL
ORDER BY salary DESC, commission_pct DESC;

--8.Liệt kê danh sách nhân viên mà có kí tự thứ 3 trong tên là “a”. 
SELECT last_name
FROM   employees
WHERE  last_name LIKE '__a%';

--9. Liệt kê danh sách nhân viên mà trong tên có chứa một chữ “a” và một chữ “e”.
SELECT last_name
FROM   employees
WHERE  last_name LIKE '%a%'
  AND  last_name LIKE '%e%';
  
--10. Cho biết tên (last_name), mã công việc (job_id), lương (salary) 
--của những nhân viên làm “Sales representative”  hoặc  “Stock clert” và có mức lương khác 
--2500$, 3500$, 7000$.
SELECT last_name, job_id, salary
FROM   employees
WHERE  job_id IN ('SA_REP', 'ST_CLERK')
  AND  salary NOT IN (2500, 3500, 7000);


--NHÓM 2: Các Hàm Xử Lý Dữ Liệu (Câu 11–16)
--11. Cho biết mã nhân viên (employee_id), tên nhân viên (last_name), 
--lương sau khi tăng thêm 15% so với lương ban đầu, được làm tròn đến 
--hàng đơn vị và đặt lại tên cột là “New Salary”. 
SELECT employee_id,
       last_name,
       ROUND(salary * 1.15, 0) AS "New Salary"
FROM   employees;

--12. Cho biết tên nhân viên, chiều dài tương ứng của tên đối với 
--những nhân viên có kí tự bắt đầu trong tên là “J”, “A”, “L”,”M”. 
--Kết quả hiển thị tăng dần theo tên, kí tự đầu của tên viết hoa, 
--các kí tự còn lại viết thường.(dùng hàm INITCAP, LENGTH, SUBSTR)
SELECT INITCAP(last_name)  AS "Ten Nhan Vien",
       LENGTH(last_name)   AS "Chieu Dai"
FROM   employees
WHERE  SUBSTR(last_name, 1, 1) IN ('J','A','L','M')
ORDER BY last_name ASC;

--13. Liệt kê danh sách nhân viên, khoảng thời gian (tính theo tháng) 
--mà Nhân viên đã làm việc trong công ty cho đến nay. Kết quả sắp xếp tăng dần 
--theo số lượng tháng làm việc. (dùng hàm MONTHS_BETWEEN).
SELECT last_name,
       TRUNC(MONTHS_BETWEEN(SYSDATE, hire_date)) AS "So Thang Lam Viec"
FROM   employees
ORDER BY MONTHS_BETWEEN(SYSDATE, hire_date) ASC;

--14. Thực hiện câu truy vấn cho kết quả theo định dạng sau : 
--<last_name> earns <salary> monthly but wants <3*salary> . Cột được hiển thị có tên “Dream Salaries”
SELECT last_name || ' earns '
    || TO_CHAR(salary, '$99,999') || ' monthly but wants '
    || TO_CHAR(salary*3, '$99,999') AS "Dream Salaries"
FROM   employees;

--15. Liệt kê tên nhân viên, mức hoa hồng nhân viên đó nhận được. 
--Trường hợp nhân viên nào không được hưởng hoa hồng thì hiển thị "No commission‟. (dùng hàm NVL) 
--cach1:
SELECT last_name,
       CASE WHEN commission_pct IS NULL THEN 'No commission'
            ELSE TO_CHAR(commission_pct)
       END AS "Commission"
FROM   employees;

--cach2:
SELECT last_name,
       NVL(TO_CHAR(commission_pct), 'No commission') AS "Commission"
FROM   employees;

--16. Thực hiện câu truy vấn cho kết quả như sau: (dùng hàm DECODE hoặc CASE…)
--JOB_ID GRADE 
•	AD_PRES A 
•	ST_MAN B 
•	IT_PROG C 
•	SA_REP D 
•	ST_CLERK E 
•	Không thuộc 0
--cach1:
SELECT job_id,
       DECODE(job_id,
              'AD_PRES',  'A',
              'ST_MAN',   'B',
              'IT_PROG',  'C',
              'SA_REP',   'D',
              'ST_CLERK', 'E',
              '0') AS "GRADE"
FROM   employees;

--cach2:
SELECT job_id,
       CASE job_id
           WHEN 'AD_PRES'  THEN 'A'
           WHEN 'ST_MAN'   THEN 'B'
           WHEN 'IT_PROG'  THEN 'C'
           WHEN 'SA_REP'   THEN 'D'
           WHEN 'ST_CLERK' THEN 'E'
           ELSE '0'
       END AS "GRADE"
FROM   employees;

--NHÓM 3: Phép Kết Nhiều Bảng - JOIN (Câu 17–21)
--17. Cho biết tên nhân viên, mã phòng, tên phòng của những nhân viên làm việc ở thành phố Toronto. 
SELECT e.last_name, e.department_id, d.department_name
FROM   employees e, departments d, locations l
WHERE  e.department_id = d.department_id
  AND  d.location_id   = l.location_id
  AND  UPPER(l.city)   = 'TORONTO';

--18. Liệt kê thông tin nhân viên cùng với người quản lý của nhân viên đó. 
--Kết quả hiển thị: mã nhân viên, tên nhân viên, mã người quản lý, tên người quản lý. 
SELECT e.employee_id  AS "Ma NV",
       e.last_name     AS "Ten NV",
       m.employee_id  AS "Ma Quan Ly",
       m.last_name     AS "Ten Quan Ly"
FROM   employees e, employees m
WHERE  e.manager_id = m.employee_id;

--19. Liệt kê danh sách những nhân viên làm việc cùng phòng.
SELECT e1.last_name AS "Nhan Vien 1",
       e2.last_name AS "Nhan Vien 2",
       e1.department_id AS "Phong Ban"
FROM   employees e1, employees e2
WHERE  e1.department_id = e2.department_id
  AND  e1.employee_id   < e2.employee_id
ORDER BY e1.department_id, e1.last_name;

--20. Liệt kê danh sách nhân viên được thuê sau nhân viên “Davies”. 
SELECT last_name, hire_date
FROM   employees
WHERE  hire_date > (SELECT hire_date
                    FROM   employees
                    WHERE  last_name = 'Davies');

--21. Liệt kê danh sách nhân viên được thuê vào làm trước người quản lý của họ.
SELECT e.last_name   AS "Nhan Vien",
       e.hire_date   AS "Ngay Vao",
       m.last_name   AS "Quan Ly",
       m.hire_date   AS "Quan Ly Vao"
FROM   employees e, employees m
WHERE  e.manager_id = m.employee_id
  AND  e.hire_date  < m.hire_date;
  
  
--NHÓM 4: GROUP BY, HAVING Và Hàm Gộp Nhóm (Câu 22–24)
--22. Cho biết lương thấp nhất, lương cao nhất, lương trung bình, tổng lương của từng loại công việc
SELECT job_id,
       MIN(salary)          AS "Luong Thap Nhat",
       MAX(salary)          AS "Luong Cao Nhat",
       ROUND(AVG(salary),2) AS "Luong Trung Binh",
       SUM(salary)          AS "Tong Luong"
FROM   employees
GROUP BY job_id
ORDER BY job_id;

--23. Cho biết mã phòng, tên phòng, số lượng nhân viên của từng phòng ban. 
--Cho biết tổng số nhân viên, tổng nhân viên được thuê từng năm 1995, 1996, 1997, 1998.
--Phần A: Số lượng nhân viên từng phòng:
SELECT d.department_id,
       d.department_name,
       COUNT(e.employee_id) AS "So Nhan Vien"
FROM   departments d LEFT JOIN employees e
       ON d.department_id = e.department_id
GROUP BY d.department_id, d.department_name
ORDER BY d.department_id;

--Phần B: Thống kê tuyển dụng theo từng năm:
SELECT COUNT(*) AS "Tong NV",
  SUM(CASE WHEN TO_CHAR(hire_date,'YYYY')='1995' THEN 1 ELSE 0 END) AS "Nam 1995",
  SUM(CASE WHEN TO_CHAR(hire_date,'YYYY')='1996' THEN 1 ELSE 0 END) AS "Nam 1996",
  SUM(CASE WHEN TO_CHAR(hire_date,'YYYY')='1997' THEN 1 ELSE 0 END) AS "Nam 1997",
  SUM(CASE WHEN TO_CHAR(hire_date,'YYYY')='1998' THEN 1 ELSE 0 END) AS "Nam 1998"
FROM   employees;

--NHÓM 5: Truy Vấn Con - Subquery (Câu 25–33)
--25. Liệt kê tên, ngày thuê của những nhân viên làm việc cùng phòng với nhân viên “Zlotkey”. 
SELECT last_name, hire_date
FROM   employees
WHERE  department_id = (SELECT department_id
                        FROM   employees
                        WHERE  last_name = 'Zlotkey')
  AND  last_name <> 'Zlotkey';

--26. Liệt kê tên nhân viên, mã phòng ban, mã công việc của những nhân viên làm việc 
--cho phòng ban đặt tại vị trí (location_id) 1700. 
SELECT last_name, department_id, job_id
FROM   employees
WHERE  department_id IN (SELECT department_id
                         FROM   departments
                         WHERE  location_id = 1700);

--27. Liệt kê danh sách nhân viên có người quản lý tên “King‟. 
SELECT last_name, manager_id
FROM   employees
WHERE  manager_id IN (SELECT employee_id
                      FROM   employees
                      WHERE  last_name = 'King');

--28. Liệt kê danh sách nhân viên có lương cao hơn mức lương trung bình và 
--làm việc cùng phòng với nhân viên có tên kết thúc bởi “n‟.
SELECT last_name, salary, department_id
FROM   employees
WHERE  salary > (SELECT AVG(salary) FROM employees)
  AND  department_id IN (SELECT department_id
                         FROM   employees
                         WHERE  last_name LIKE '%n');

--29. Liệt kê danh sách mã phòng ban, tên phòng ban có ít hơn 3 nhân viên. 
--cach1: Correlated Subquery:
SELECT department_id, department_name
FROM   departments d
WHERE  (SELECT COUNT(*) FROM employees e
        WHERE e.department_id = d.department_id) < 3
ORDER BY department_id;

--cach2: GROUP BY / HAVING
SELECT d.department_id, d.department_name, COUNT(e.employee_id) AS "So NV"
FROM   departments d LEFT JOIN employees e
       ON d.department_id = e.department_id
GROUP BY d.department_id, d.department_name
HAVING COUNT(e.employee_id) < 3
ORDER BY d.department_id;

--30. Cho biết phòng ban nào có đông nhân viên nh ất, phòng ban nào có ít nhân viên nhất.
SELECT department_id, COUNT(*) AS "So Nhan Vien", 'Dong nhat' AS "Loai"
FROM   employees
GROUP BY department_id
HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM employees GROUP BY department_id)
UNION ALL
SELECT department_id, COUNT(*), 'It nhat'
FROM   employees
GROUP BY department_id
HAVING COUNT(*) = (SELECT MIN(COUNT(*)) FROM employees GROUP BY department_id);

--31. Liệt kê danh sách nhân viên được thuê vào ngày có số lượng nhân viên 
--được thuê đông nhất. (dùng hàm TO_CHAR(hire_date, “Day‟)). 
SELECT last_name, hire_date,
       TO_CHAR(hire_date,'Day') AS "Thu trong tuan"
FROM   employees
WHERE  TO_CHAR(hire_date,'Day') IN (
    SELECT TO_CHAR(hire_date,'Day')
    FROM   employees
    GROUP BY TO_CHAR(hire_date,'Day')
    HAVING COUNT(*) = (
        SELECT MAX(COUNT(*))
        FROM   employees
        GROUP BY TO_CHAR(hire_date,'Day')
    )
);

--32. Liệt kê thông tin 3 nhân viên có lương cao nhất. 
SELECT last_name, salary
FROM (
    SELECT last_name, salary
    FROM   employees
    ORDER BY salary DESC
)
WHERE ROWNUM <= 3;

--33. Liệt kê danh sách nhân viên đang làm việc ở tiểu bang “California”.
SELECT e.last_name, e.department_id
FROM   employees    e,
       departments  d,
       locations    l
WHERE  e.department_id = d.department_id
  AND  d.location_id   = l.location_id
  AND  UPPER(l.state_province) = 'CALIFORNIA';
  
--NHÓM 6: DML - Cập Nhật Và Xóa Dữ Liệu (Câu 34–38)
--34. Cập nhật tên của nhân viên có mã 3 thành  “Drexler‟.
UPDATE employees
SET    last_name = 'Drexler'
WHERE  employee_id = 3;

COMMIT;

--35. Liệt kê danh sách nhân viên có mức lương thấp hơn mức lương 
--trung bình của phòng ban mà nhân viên đó làm vi ệc.
SELECT e1.last_name, e1.salary, e1.department_id
FROM   employees e1
WHERE  e1.salary < (SELECT AVG(e2.salary)
                    FROM   employees e2
                    WHERE  e2.department_id = e1.department_id)
ORDER BY e1.department_id;

--36. Tăng thêm 100$ cho những nhân viên có lương nhỏ hơn 900$. 
UPDATE employees
SET    salary = salary + 100
WHERE  salary < 900;

COMMIT;

--37. Xóa phòng ban 500. 
DELETE FROM departments WHERE department_id = 500;

COMMIT;

--38. Xóa phòng ban nào chưa có nhân viên.
--Cách 1: NOT IN (chú ý xử lý NULL):
DELETE FROM departments
WHERE  department_id NOT IN (
    SELECT DISTINCT department_id FROM employees
    WHERE  department_id IS NOT NULL
);
COMMIT;

--Cách 2: NOT EXISTS (an toàn hơn với NULL):
DELETE FROM departments d
WHERE NOT EXISTS (
    SELECT 1 FROM employees e
    WHERE e.department_id = d.department_id
);
COMMIT;

