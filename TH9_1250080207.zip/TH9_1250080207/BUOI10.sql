-- Thêm Hãng Sản Xuất
INSERT INTO HangSX VALUES ('HSX01', 'Samsung', 'Han Quoc', '0901234567', 'contact@samsung.com');
INSERT INTO HangSX VALUES ('HSX02', 'Apple', 'My', '0987654321', 'contact@apple.com');
SELECT * FROM HangSX; 
-- Thêm Nhân Viên
INSERT INTO NhanVien VALUES ('NV01', 'Nguyen Van A', 'Nam', 'Ha Noi', '0911223344', 'nva@gmail.com', 'Kho');
INSERT INTO NhanVien VALUES ('NV02', 'Tran Thi B', 'Nu', 'TP HCM', '0922334455', 'ttb@gmail.com', 'Ban Hang');

-- Thêm Sản Phẩm
INSERT INTO SanPham VALUES ('SP01', 'HSX01', 'Samsung Galaxy S23', 100, 'Den', 20000000, 'Chiec', 'Dien thoai cao cap');
INSERT INTO SanPham VALUES ('SP02', 'HSX02', 'iPhone 15 Pro', 50, 'Trang', 25000000, 'Chiec', 'Dien thoai hot nhat');

-- Thêm Phiếu Nhập & Chi tiết Nhập
INSERT INTO PNhap VALUES ('PN01', SYSDATE - 5, 'NV01');
INSERT INTO Nhap VALUES ('PN01', 'SP01', 100, 15000000);
INSERT INTO Nhap VALUES ('PN01', 'SP02', 50, 20000000);

-- Thêm Phiếu Xuất & Chi tiết Xuất
INSERT INTO PXuat VALUES ('PX01', SYSDATE - 1, 'NV02');
INSERT INTO Xuat VALUES ('PX01', 'SP01', 10);
INSERT INTO Xuat VALUES ('PX01', 'SP02', 5);
SELECT * FROM PXuat; 

-- Lưu lại toàn bộ dữ liệu
COMMIT;

--Phiéu bải tập 1
--a. Trigger INSERT bảng NHAP – trg_Nhap
CREATE OR REPLACE TRIGGER trg_Nhap
BEFORE INSERT ON Nhap
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
BEGIN
    -- 1. Kiểm tra ràng buộc toàn vẹn: MaSP có tồn tại trong bảng SanPham không?
    SELECT COUNT(*) INTO v_dem FROM SanPham WHERE MaSP = :NEW.MaSP;
    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Loi: Ma san pham khong ton tai!');
    END IF;

    -- 2. Kiểm tra ràng buộc dữ liệu: SoLuongN > 0 và DonGiaN > 0?
    IF :NEW.SoLuongN <= 0 OR :NEW.DonGiaN <= 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Loi: So luong va Don gia nhap phai > 0!');
    END IF;

    -- 3. Hợp lệ -> cập nhật SoLuong trong SanPham
    UPDATE SanPham
    SET SoLuong = SoLuong + :NEW.SoLuongN
    WHERE MaSP = :NEW.MaSP;
END trg_Nhap;
/
SELECT * FROM HangSX;

--test 
--Số lượng âm (Sẽ bị chặn)
INSERT INTO Nhap VALUES ('N01', 'SP01', -10, 10000);

-- Nhập 20 cái SP01 
INSERT INTO Nhap VALUES ('N01', 'SP01', 20, 14000000);
COMMIT;
SELECT * FROM SanPham WHERE MaSP = 'SP01';


--b. Trigger INSERT bảng XUAT – trg_xuat
CREATE OR REPLACE TRIGGER trg_xuat
BEFORE INSERT ON Xuat
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
    v_sl_ton NUMBER := 0;
BEGIN
    -- 1. Kiểm tra MaSP
    SELECT COUNT(*) INTO v_dem FROM SanPham WHERE MaSP = :NEW.MaSP;
    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Loi: Ma san pham khong ton tai!');
    END IF;

    -- 2. Kiểm tra tồn kho
    SELECT SoLuong INTO v_sl_ton FROM SanPham WHERE MaSP = :NEW.MaSP;
    IF :NEW.SoLuongX > v_sl_ton THEN
        RAISE_APPLICATION_ERROR(-20002, 'Loi: So luong xuat vuot qua ton kho!');
    END IF;

    -- 3. Cập nhật tồn kho
    UPDATE SanPham
    SET SoLuong = SoLuong - :NEW.SoLuongX
    WHERE MaSP = :NEW.MaSP;
END trg_xuat;
/

--test$
--Xuất quá tồn kho (SP01 đang có 120, xuất 200 -> Bị chặn)
INSERT INTO Xuat VALUES ('X01', 'SP01', 200);

--Xuất 10 cái (Thành công, SP01 còn 110)
INSERT INTO Xuat VALUES ('X01', 'SP01', 10);
COMMIT;
SELECT * FROM SanPham WHERE MaSP = 'SP01';

--c. Trigger DELETE bảng XUAT – trg_XoaXuat
CREATE OR REPLACE TRIGGER trg_XoaXuat
AFTER DELETE ON Xuat
FOR EACH ROW
BEGIN
    -- Hoàn trả số lượng khi xóa bản ghi
    UPDATE SanPham
    SET SoLuong = SoLuong + :OLD.SoLuongX
    WHERE MaSP = :OLD.MaSP;
END trg_XoaXuat;
/

--test
-- Xóa phiếu xuất vừa tạo ở câu b
DELETE FROM Xuat WHERE SoHDX = 'X01' AND MaSP = 'SP01';
COMMIT;

-- Xem lại tồn kho: SP01 được hoàn trả 10 cái, quay về 120
SELECT * FROM SanPham WHERE MaSP = 'SP01';


--PHIẾU BÀI TẬP 2
--Tạo package lưu biến đếm dùng cho các Compound Trigger
CREATE OR REPLACE PACKAGE pkg_state AS 
    g_row_count NUMBER := 0; 
END pkg_state; 
/

--a. Trigger UPDATE bảng XUAT – trg_CapNhatXuat
CREATE OR REPLACE TRIGGER trg_CapNhatXuat
FOR UPDATE ON Xuat
COMPOUND TRIGGER
    -- Chạy trước toàn bộ câu lệnh -> reset biến đếm
    BEFORE STATEMENT IS
    BEGIN
        pkg_state.g_row_count := 0; 
    END BEFORE STATEMENT;

    -- Kiểm tra cho từng dòng
    BEFORE EACH ROW IS
        v_sl_ton NUMBER := 0;
    BEGIN
        pkg_state.g_row_count := pkg_state.g_row_count + 1;
        -- Kiểm tra nếu cập nhật > 1 dòng
        IF pkg_state.g_row_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Loi: Chi duoc cap nhat 1 ban ghi!');
        END IF;

        -- Kiểm tra số lượng tồn kho có đủ bù chênh lệch không
        IF :NEW.SoLuongX <> :OLD.SoLuongX THEN
            SELECT SoLuong INTO v_sl_ton FROM SanPham WHERE MaSP = :NEW.MaSP;
            IF (:NEW.SoLuongX - :OLD.SoLuongX) > v_sl_ton THEN
                RAISE_APPLICATION_ERROR(-20002, 'Loi: Khong du hang xuat de bu phan chenh lech!');
            END IF;
        END IF;
    END BEFORE EACH ROW;

    -- Hợp lệ thì cập nhật bảng SanPham
    AFTER EACH ROW IS
    BEGIN
        IF :NEW.SoLuongX <> :OLD.SoLuongX THEN
            UPDATE SanPham
            SET SoLuong = SoLuong - (:NEW.SoLuongX - :OLD.SoLuongX)
            WHERE MaSP = :NEW.MaSP;
        END IF;
    END AFTER EACH ROW;
END trg_CapNhatXuat;
/

--TEST
-- TEST đúng : Sửa lượng xuất của SP01 từ 10 thành 15 (Chênh lệch 5 cái)
-- (Sản phẩm SP01 đang có 100 cái trong kho, sẽ bị trừ 5 cái còn 95)
UPDATE Xuat SET SoLuongX = 15 WHERE SoHDX = 'PX01' AND MaSP = 'SP01';
COMMIT;
SELECT * FROM SanPham WHERE MaSP = 'SP01'; 

-- TEST lỗi : Xuất bù thêm 500 cái (Vượt tồn kho 95 cái -> Sẽ bị chặn)
UPDATE Xuat SET SoLuongX = 515 WHERE SoHDX = 'PX01' AND MaSP = 'SP01';

-- TEST LỖI COMPOUND: Cố tình cập nhật không có WHERE để dính nhiều dòng
UPDATE Xuat SET SoLuongX = 20;

--b. Trigger UPDATE bảng NHAP – trg_CapNhatNhap
CREATE OR REPLACE TRIGGER trg_CapNhatNhap
FOR UPDATE ON Nhap
COMPOUND TRIGGER
    BEFORE STATEMENT IS
    BEGIN
        pkg_state.g_row_count := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
    BEGIN
        pkg_state.g_row_count := pkg_state.g_row_count + 1;
        IF pkg_state.g_row_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Loi: Chi duoc cap nhat 1 ban ghi!');
        END IF;
    END BEFORE EACH ROW;

    AFTER EACH ROW IS
    BEGIN
        IF :NEW.SoLuongN <> :OLD.SoLuongN THEN
            UPDATE SanPham
            SET SoLuong = SoLuong + (:NEW.SoLuongN - :OLD.SoLuongN)
            WHERE MaSP = :NEW.MaSP;
        END IF;
    END AFTER EACH ROW;
END trg_CapNhatNhap;
/

--test
-- test đúng: sửa lượng nhập của SP02 từ 50 thành 70 (Chênh lệch 20 cái)
-- (Kho SP02 sẽ tăng từ 50 lên 70)
UPDATE Nhap SET SoLuongN = 70 WHERE SoHDN = 'PN01' AND MaSP = 'SP02';
COMMIT;
SELECT * FROM SanPham WHERE MaSP = 'SP02'; 

--c. Trigger DELETE bảng NHAP – trg_XoaNhap
CREATE OR REPLACE TRIGGER trg_XoaNhap
AFTER DELETE ON Nhap
FOR EACH ROW
BEGIN
    UPDATE SanPham
    SET SoLuong = SoLuong - :OLD.SoLuongN
    WHERE MaSP = :OLD.MaSP;
END trg_XoaNhap;
/


--PHIẾU BÀI TẬP 3
--CẤU TRÚC CSDL
-- Xóa bảng cũ nếu có
DROP TABLE LichSuPhong CASCADE CONSTRAINTS;
DROP TABLE ChiPhiPhuThu CASCADE CONSTRAINTS;
DROP TABLE HoaDon CASCADE CONSTRAINTS;
DROP TABLE KhachHang CASCADE CONSTRAINTS;
DROP TABLE Phong CASCADE CONSTRAINTS;
DROP SEQUENCE SEQ_HD;

-- Tạo Bảng
CREATE TABLE Phong (
    MaPhong VARCHAR2(10) PRIMARY KEY, 
    LoaiPhong VARCHAR2(50), 
    TrangThai VARCHAR2(20), -- 'TRONG' | 'DA_THUE' | 'BAO_TRI'
    GiaTheoGio NUMBER(15,2), 
    GiaTheoNgay NUMBER(15,2), 
    SoNguoiToiDa NUMBER
);

CREATE TABLE KhachHang (
    MaKH VARCHAR2(10) PRIMARY KEY, 
    HoTen VARCHAR2(50), 
    CCCD VARCHAR2(20), 
    SoDT VARCHAR2(15),  
    Email VARCHAR2(50), 
    QuocTich VARCHAR2(50)
);

CREATE TABLE HoaDon (
    MaHD VARCHAR2(10) PRIMARY KEY, 
    MaKH VARCHAR2(10) REFERENCES KhachHang(MaKH), 
    MaPhong VARCHAR2(10) REFERENCES Phong(MaPhong), 
    NgayNhan DATE, 
    NgayTra DATE, 
    SoNguoi NUMBER,  
    TongTien NUMBER(15,2), 
    TrangThai VARCHAR2(20) 
);

CREATE TABLE ChiPhiPhuThu (
    MaCP VARCHAR2(10) PRIMARY KEY, 
    MaHD VARCHAR2(10) REFERENCES HoaDon(MaHD), 
    MoTa VARCHAR2(100), 
    SoTien NUMBER(15,2), 
    ThoiGian DATE
);

CREATE TABLE LichSuPhong (
    MaLS VARCHAR2(10) PRIMARY KEY, 
    MaPhong VARCHAR2(10) REFERENCES Phong(MaPhong),  
    MaHD VARCHAR2(10) REFERENCES HoaDon(MaHD), 
    NgayNhan DATE, 
    NgayTra DATE, 
    GhiChu VARCHAR2(200)
);

-- Dữ liệu mẫu
-- 1. KHÁCH HÀNG
INSERT INTO KhachHang VALUES ('KH01', 'Nguyen Van A', '079123456789', '0901234567', 'nva@gmail.com', 'Viet Nam');
INSERT INTO KhachHang VALUES ('KH02', 'Tran Thi B', '079987654321', '0987654321', 'ttb@gmail.com', 'Viet Nam');
INSERT INTO KhachHang VALUES ('KH03', 'John Doe', 'P1234567', '0911223344', 'john@us.com', 'USA');
INSERT INTO KhachHang VALUES ('KH04', 'Pham Thi C', '072222333444', '0933445566', 'ptc@gmail.com', 'Viet Nam');

-- 2. PHÒNG 
INSERT INTO Phong VALUES ('P101', 'VIP', 'TRONG', 200000, 1000000, 2);
INSERT INTO Phong VALUES ('P102', 'Standard', 'TRONG', 100000, 500000, 4);
INSERT INTO Phong VALUES ('P103', 'Family', 'DA_THUE', 300000, 1500000, 6);
INSERT INTO Phong VALUES ('P201', 'VIP', 'BAO_TRI', 250000, 1200000, 2);
INSERT INTO Phong VALUES ('P202', 'Standard', 'TRONG', 100000, 500000, 2);

-- 3. HÓA ĐƠN 
INSERT INTO HoaDon VALUES ('HD01', 'KH01', 'P103', TRUNC(SYSDATE) - 2, TRUNC(SYSDATE) + 1, 4, 3000000, 'DANG_O');
INSERT INTO HoaDon VALUES ('HD02', 'KH02', 'P102', TRUNC(SYSDATE) - 10, TRUNC(SYSDATE) - 8, 2, 1000000, 'DA_TRA');
INSERT INTO HoaDon VALUES ('HD03', 'KH03', 'P101', TRUNC(SYSDATE), TRUNC(SYSDATE) + 3, 1, 3000000, 'CHO_NHAN');

-- 4. CHI PHÍ PHỤ THU
INSERT INTO ChiPhiPhuThu VALUES ('CP01', 'HD01', 'Nuoc suoi', 20000, SYSDATE - 1);
INSERT INTO ChiPhiPhuThu VALUES ('CP02', 'HD01', 'Giat ui', 150000, SYSDATE);
INSERT INTO ChiPhiPhuThu VALUES ('CP03', 'HD02', 'Hư hao khan tam', 50000, SYSDATE - 8);

-- 5.LỊCH SỬ PHÒNG
INSERT INTO LichSuPhong VALUES ('LS01', 'P102', 'HD02', TRUNC(SYSDATE) - 10, TRUNC(SYSDATE) - 8, 'Khach check-out dung gio');

COMMIT;

--a. Trigger INSERT bảng HoaDon — trg_DatPhong
CREATE OR REPLACE TRIGGER trg_DatPhong
BEFORE INSERT ON HoaDon
FOR EACH ROW
DECLARE
    v_dem_kh NUMBER := 0;
    v_dem_phong NUMBER := 0;
    v_trangthai_phong VARCHAR2(20);
    v_songuoi_max NUMBER := 0;
    v_gia_ngay NUMBER(15,2) := 0;
BEGIN
    -- Kiểm tra MaKH
    SELECT COUNT(*) INTO v_dem_kh FROM KhachHang WHERE MaKH = :NEW.MaKH;
    IF v_dem_kh = 0 THEN RAISE_APPLICATION_ERROR(-20001, 'Khach hang khong ton tai!'); END IF;

    -- Kiểm tra MaPhong
    SELECT COUNT(*) INTO v_dem_phong FROM Phong WHERE MaPhong = :NEW.MaPhong;
    IF v_dem_phong = 0 THEN RAISE_APPLICATION_ERROR(-20002, 'Phong khong ton tai!'); END IF;

    -- Lấy thông tin phòng để kiểm tra
    SELECT TrangThai, SoNguoiToiDa, GiaTheoNgay 
    INTO v_trangthai_phong, v_songuoi_max, v_gia_ngay 
    FROM Phong WHERE MaPhong = :NEW.MaPhong;

    -- Kiểm tra TrangThai phòng và SoNguoi
    IF v_trangthai_phong <> 'TRONG' THEN RAISE_APPLICATION_ERROR(-20003, 'Phong khong con trong!'); END IF;
    IF :NEW.SoNguoi > v_songuoi_max THEN RAISE_APPLICATION_ERROR(-20004, 'So nguoi vuot qua quy dinh!'); END IF;

    -- Kiểm tra NgayNhan, NgayTra
    IF :NEW.NgayNhan >= :NEW.NgayTra OR :NEW.NgayNhan < TRUNC(SYSDATE) THEN 
        RAISE_APPLICATION_ERROR(-20005, 'Ngay nhan hoac ngay tra khong hop le!'); 
    END IF;

    -- Tính TongTien và gán vào :NEW (Vì là BEFORE trigger nên gán trực tiếp được)
    :NEW.TongTien := (:NEW.NgayTra - :NEW.NgayNhan) * v_gia_ngay;

    -- Cập nhật TrangThai phòng
    UPDATE Phong SET TrangThai = 'DA_THUE' WHERE MaPhong = :NEW.MaPhong;
END trg_DatPhong;
/

--test
-- Test đúng : Khách KH04 đặt phòng P102 (đang TRONG), ở 2 người, 2 ngày.
INSERT INTO HoaDon (MaHD, MaKH, MaPhong, NgayNhan, NgayTra, SoNguoi, TrangThai)
VALUES ('HD04', 'KH04', 'P102', TRUNC(SYSDATE), TRUNC(SYSDATE)+2, 2, 'CHO_NHAN');
COMMIT;

-- Xem lại bảng Phong: P102 đã tự động chuyển thành 'DA_THUE'
SELECT MaPhong, TrangThai FROM Phong WHERE MaPhong = 'P102';

-- Test lỗi: Cố tình đặt phòng P201 (đang BAO_TRI) -> Bị chặn
INSERT INTO HoaDon (MaHD, MaKH, MaPhong, NgayNhan, NgayTra, SoNguoi, TrangThai)
VALUES ('HD05', 'KH01', 'P201', TRUNC(SYSDATE), TRUNC(SYSDATE)+1, 1, 'CHO_NHAN');

--b. Trigger UPDATE TrangThai HoaDon — trg_CapNhatTrangThaiHD
CREATE OR REPLACE TRIGGER trg_CapNhatTrangThaiHD
BEFORE UPDATE OF TrangThai ON HoaDon
FOR EACH ROW
BEGIN
    -- KHÔNG được đổi trạng thái nếu đã trả hoặc đã hủy [cite: 347]
    IF :OLD.TrangThai IN ('DA_TRA', 'HUY') THEN
        RAISE_APPLICATION_ERROR(-20001, 'Khong the thay doi trang thai khi da Tra phong hoac Huy!');
    END IF;

    -- Chờ nhận -> Đang ở hoặc Hủy [cite: 346]
    IF :OLD.TrangThai = 'CHO_NHAN' AND :NEW.TrangThai NOT IN ('DANG_O', 'HUY') THEN
        RAISE_APPLICATION_ERROR(-20002, 'Chuyen trang thai khong hop le tu CHO_NHAN!');
    END IF;

    -- Đang ở -> Đã trả [cite: 347]
    IF :OLD.TrangThai = 'DANG_O' AND :NEW.TrangThai <> 'DA_TRA' THEN
        RAISE_APPLICATION_ERROR(-20003, 'Chuyen trang thai khong hop le tu DANG_O!');
    END IF;

    -- Xử lý hành động đi kèm [cite: 348, 349]
    IF :NEW.TrangThai = 'DA_TRA' THEN
        UPDATE Phong SET TrangThai = 'TRONG' WHERE MaPhong = :NEW.MaPhong;
        INSERT INTO LichSuPhong (MaLS, MaPhong, MaHD, NgayNhan, NgayTra, GhiChu) 
        VALUES (SUBSTR(RAWTOHEX(SYS_GUID()), 1, 10), :NEW.MaPhong, :NEW.MaHD, :NEW.NgayNhan, :NEW.NgayTra, 'Hoan thanh');
        
    ELSIF :NEW.TrangThai = 'HUY' THEN
        UPDATE Phong SET TrangThai = 'TRONG' WHERE MaPhong = :NEW.MaPhong;
    END IF;
END trg_CapNhatTrangThaiHD;
/

--test
-- Test đúng: Khách HD03 đang 'CHO_NHAN', giờ đến nhận phòng -> 'DANG_O'
UPDATE HoaDon SET TrangThai = 'DANG_O' WHERE MaHD = 'HD03';
COMMIT;

UPDATE HoaDon SET TrangThai = 'DA_TRA' WHERE MaHD = 'HD01';
COMMIT;

-- Xem lại bảng Phong & Lịch sử: P103 đã chuyển về 'TRONG' và có thêm dòng lịch sử mới
SELECT MaPhong, TrangThai FROM Phong WHERE MaPhong = 'P103';
SELECT * FROM LichSuPhong WHERE MaHD = 'HD01';

-- Test sai : HD02 đã 'DA_TRA' trong quá khứ, cố tình chuyển về 'DANG_O' -> Bị chặn
UPDATE HoaDon SET TrangThai = 'DANG_O' WHERE MaHD = 'HD02';

--c. Compound Trigger UPDATE ChiPhiPhuThu — trg_SuaChiPhi
CREATE OR REPLACE TRIGGER trg_SuaChiPhi
FOR INSERT OR UPDATE ON ChiPhiPhuThu
COMPOUND TRIGGER
    v_dem NUMBER := 0;
    TYPE t_mahd_list IS TABLE OF VARCHAR2(10) INDEX BY VARCHAR2(10);
    v_mahd_capnhat t_mahd_list;
    v_mahd_hientai VARCHAR2(10);

    BEFORE STATEMENT IS
    BEGIN
        v_dem := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
    BEGIN
        v_dem := v_dem + 1;
        IF v_dem > 5 THEN RAISE_APPLICATION_ERROR(-20001, 'Chi duoc thao tac toi da 5 chi phi cung luc!'); END IF;

        IF :NEW.SoTien <= 0 OR :NEW.SoTien >= 50000000 THEN
            RAISE_APPLICATION_ERROR(-20002, 'So tien phai tu 0 den 50,000,000!');
        END IF;
        
        v_mahd_capnhat(:NEW.MaHD) := :NEW.MaHD;
    END BEFORE EACH ROW;

    AFTER STATEMENT IS
        v_tong_phuthu NUMBER := 0;
    BEGIN
        v_mahd_hientai := v_mahd_capnhat.FIRST;
        WHILE v_mahd_hientai IS NOT NULL LOOP
            SELECT NVL(SUM(SoTien), 0) INTO v_tong_phuthu 
            FROM ChiPhiPhuThu WHERE MaHD = v_mahd_hientai;
            
            UPDATE HoaDon 
            SET TongTien = ((NgayTra - NgayNhan) * (SELECT GiaTheoNgay FROM Phong WHERE MaPhong = HoaDon.MaPhong)) + v_tong_phuthu
            WHERE MaHD = v_mahd_hientai;

            v_mahd_hientai := v_mahd_capnhat.NEXT(v_mahd_hientai);
        END LOOP;
    END AFTER STATEMENT;
END trg_SuaChiPhi;
/

--test
-- Xem TongTien hiện tại của HD03 (Đang là 3,000,000 cho 3 ngày phòng P101)
SELECT TongTien FROM HoaDon WHERE MaHD = 'HD03';

--Khách HD03 gọi thêm đồ ăn giá 500,000
INSERT INTO ChiPhiPhuThu VALUES ('CP04', 'HD03', 'An trua', 500000, SYSDATE);
COMMIT;

-- Xem lại TongTien HD03: Đã tự động tăng lên 3,500,000
SELECT TongTien FROM HoaDon WHERE MaHD = 'HD03';

-- Test sai: Thêm phụ thu giá 80 triệu (Vượt quá 50 triệu) -> Bị chặn
INSERT INTO ChiPhiPhuThu VALUES ('CP05', 'HD03', 'Phat lam chay giuong', 80000000, SYSDATE);

--d. INSTEAD OF Trigger trên View — trg_vwPhongTrong_ins
-- Tạo View 
CREATE OR REPLACE VIEW vw_PhongTrong AS
SELECT MaPhong, LoaiPhong, GiaTheoNgay, SoNguoiToiDa
FROM Phong
WHERE TrangThai = 'TRONG';

-- Tạo Sequence nếu chưa có (Nếu báo "name is already used" thì cứ bỏ qua bước này)
CREATE SEQUENCE SEQ_HD START WITH 100 INCREMENT BY 1;

-- Tạo INSTEAD OF Trigger 
CREATE OR REPLACE TRIGGER trg_vwPhongTrong_ins
INSTEAD OF INSERT ON vw_PhongTrong
FOR EACH ROW
DECLARE
    v_mahd_moi VARCHAR2(10);
BEGIN
    v_mahd_moi := 'HD' || TO_CHAR(SEQ_HD.NEXTVAL, 'FM0000');

    -- Tự động gán khách hàng KH01 và sinh hóa đơn
    INSERT INTO HoaDon (MaHD, MaKH, MaPhong, NgayNhan, NgayTra, SoNguoi, TrangThai)
    VALUES (v_mahd_moi, 'KH01', :NEW.MaPhong, TRUNC(SYSDATE), TRUNC(SYSDATE)+1, 1, 'CHO_NHAN');
    
    DBMS_OUTPUT.PUT_LINE('Dat phong qua View thanh cong. MaHD: ' || v_mahd_moi);
END trg_vwPhongTrong_ins;
/

--test
SET SERVEROUTPUT ON
--Đặt phòng P202 (đang TRONG) qua View
INSERT INTO vw_PhongTrong (MaPhong) VALUES ('P202');
COMMIT;

-- Xem lại Hóa Đơn, bạn sẽ thấy HD0100 (hoặc mã tương tự) vừa được tạo tự động cho phòng P202
SELECT * FROM HoaDon WHERE MaPhong = 'P202';