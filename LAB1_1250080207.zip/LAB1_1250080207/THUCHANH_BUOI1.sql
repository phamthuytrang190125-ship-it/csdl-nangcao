--BÀI 1 
SHOW USER;

--Tạo bảng 
CREATE TABLE s_region (
    id NUMBER(7) CONSTRAINT s_region_id_pk PRIMARY KEY,
    name VARCHAR2(50) NOT NULL
);

CREATE TABLE s_title (
    title VARCHAR2(50) PRIMARY KEY
);

CREATE TABLE s_image (
    id NUMBER(7) PRIMARY KEY,
    format VARCHAR2(25),
    use_filename VARCHAR2(1),
    filename VARCHAR2(50),
    image BLOB
);

CREATE TABLE s_longtext (
    id NUMBER(7) PRIMARY KEY,
    use_filename VARCHAR2(1),
    filename VARCHAR2(50),
    text CLOB
);

CREATE TABLE s_dept (
    id NUMBER(7) CONSTRAINT s_dept_id_pk PRIMARY KEY,
    name VARCHAR2(25) NOT NULL,
    region_id NUMBER(7) CONSTRAINT s_dept_region_id_fk REFERENCES s_region(id)
);

CREATE TABLE s_emp (
    id NUMBER(7) CONSTRAINT s_emp_id_pk PRIMARY KEY,
    last_name VARCHAR2(25) NOT NULL,
    first_name VARCHAR2(25),
    userid VARCHAR2(8) UNIQUE,
    start_date DATE,
    comments VARCHAR2(255),
    manager_id NUMBER(7),
    title VARCHAR2(25),
    dept_id NUMBER(7),
    salary NUMBER(11,2),
    commission_pct NUMBER(4,2)
);

CREATE TABLE s_warehouse (
    id NUMBER(7) PRIMARY KEY,
    region_id NUMBER(7) REFERENCES s_region(id),
    address VARCHAR2(50),
    city VARCHAR2(30),
    state VARCHAR2(20),
    country VARCHAR2(30),
    zip_code VARCHAR2(15),
    phone VARCHAR2(20),
    manager_id NUMBER(7) REFERENCES s_emp(id)
);

CREATE TABLE s_customer(
    id NUMBER(7) PRIMARY KEY,
    name VARCHAR2(50),
    phone VARCHAR2(20),
    address VARCHAR2(50),
    city VARCHAR2(30),
    state VARCHAR2(20),
    country VARCHAR2(30),
    zip_code VARCHAR2(15),
    credit_rating VARCHAR2(10),
    sales_rep_id NUMBER(7),
    region_id NUMBER(7),
    comments VARCHAR2(255)
);

CREATE TABLE s_product (
    id NUMBER(7) PRIMARY KEY,
    name VARCHAR2(50),
    short_desc VARCHAR2(255),
    longtext_id NUMBER(7),
    image_id NUMBER(7),
    suggested_whlsl_price NUMBER(11,2),
    whlsl_units VARCHAR2(25)
);

CREATE TABLE s_ord(
    id NUMBER(7) PRIMARY KEY,
    customer_id NUMBER(7),
    date_ordered DATE,
    date_shipped DATE,
    sales_rep_id NUMBER(7),
    total NUMBER(11,2),
    payment_type VARCHAR2(15),
    order_filled VARCHAR2(1)
);

CREATE TABLE s_item (
    ord_id NUMBER(7),
    item_id NUMBER(7),
    product_id NUMBER(7),
    price NUMBER(11,2),
    quantity NUMBER(7),
    quantity_shipped NUMBER(7),
    PRIMARY KEY (ord_id, item_id)
);

CREATE TABLE s_inventory (
    product_id NUMBER(7) REFERENCES s_product(id),
    warehouse_id NUMBER(7) REFERENCES s_warehouse(id),
    amount_in_stock NUMBER(7),
    reorder_point NUMBER(7),
    max_in_stock NUMBER(7),
    out_of_stock_explanation VARCHAR2(255),
    restock_date DATE,
    PRIMARY KEY (product_id, warehouse_id)
);

--Kiểm tra cấu trúc bảng 
DESC s_emp; 
DESC s_dept; 

-- Xem danh sach tat ca bang cua user hien tai: 
SELECT table_name FROM user_tables ORDER BY table_name;


--Chèn dữ liệu
INSERT INTO s_region VALUES (1, 'North America');
INSERT INTO s_region VALUES (2, 'South America');
INSERT INTO s_region VALUES (3, 'Asia');
INSERT INTO s_region VALUES (4, 'Vietnam');
INSERT INTO s_region VALUES (5, 'Japan');
INSERT INTO s_region VALUES (6, 'South Korea');
INSERT INTO s_region VALUES (7, 'Thailand');
INSERT INTO s_region VALUES (8, 'Singapore');
INSERT INTO s_region VALUES (9, 'United Kingdom');
INSERT INTO s_region VALUES (10, 'France');
INSERT INTO s_region VALUES (11, 'Germany');
INSERT INTO s_region VALUES (12, 'Italy');
INSERT INTO s_region VALUES (13, 'Spain');
INSERT INTO s_region VALUES (14, 'Australia');
INSERT INTO s_region VALUES (15, 'New Zealand');
INSERT INTO s_region VALUES (16, 'Brazil');
INSERT INTO s_region VALUES (17, 'Argentina');
INSERT INTO s_region VALUES (18, 'Egypt');
INSERT INTO s_region VALUES (19, 'South Africa');
INSERT INTO s_region VALUES (20, 'Canada');

SELECT * FROM s_region;

INSERT INTO s_title VALUES ('Giam doc');
INSERT INTO s_title VALUES ('Truong phong');
INSERT INTO s_title VALUES ('Nhan vien');
INSERT INTO s_title VALUES ('Sale Rep');
INSERT INTO s_title VALUES ('Ky thuat');
SELECT * FROM s_title;

INSERT INTO s_image VALUES (1, 'JPEG', 'Y', 'pro.jpg', NULL);
INSERT INTO s_image VALUES (2, 'PNG', 'Y', 'bike.png', NULL);
SELECT * FROM s_image;

INSERT INTO s_longtext VALUES (1, 'N', NULL, 'Chi tiet Pro');
INSERT INTO s_longtext VALUES (2, 'N', NULL, 'Chi tiet Xe dap');
SELECT * FROM s_longtext;

INSERT INTO s_dept VALUES (10, 'Finance NA', 1);
INSERT INTO s_dept VALUES (31, 'Sales Asia', 3);
INSERT INTO s_dept VALUES (42, 'IT VN', 4);
INSERT INTO s_dept VALUES (50, 'Marketing UK', 9);
INSERT INTO s_dept VALUES (60, 'HR Japan', 5);
INSERT INTO s_dept VALUES (70, 'Ops Australia', 14);
INSERT INTO s_dept VALUES (80, 'R&D Germany', 11);
INSERT INTO s_dept VALUES (90, 'Support Brazil', 16);
SELECT * FROM s_dept;

-- Sếp tổng 
INSERT INTO s_emp VALUES (1, 'Nguyen', 'Thanh', 'nthanh', TO_DATE('14/05/1990','DD/MM/YYYY'), NULL, NULL, 'Giam doc', 10, 5000, NULL);
-- Các sếp chi nhánh
INSERT INTO s_emp VALUES (2, 'Tran', 'Lan', 'tlan', TO_DATE('01/06/1991','DD/MM/YYYY'), NULL, 1, 'Truong phong', 42, 2000, NULL);
INSERT INTO s_emp VALUES (3, 'Smith', 'John', 'jsmith', TO_DATE('15/05/1991','DD/MM/YYYY'), NULL, 1, 'Truong phong', 50, 2200, NULL);

-- 19 Nhân viên trực tiếp báo cáo cho Sếp tổng 
INSERT INTO s_emp VALUES (4, 'Pham', 'Son', 'pson', TO_DATE('10/10/1991','DD/MM/YYYY'), NULL, 1, 'Nhan vien', 31, 1400, NULL);
INSERT INTO s_emp VALUES (5, 'Le', 'Hoa', 'lhoa', TO_DATE('20/03/1992','DD/MM/YYYY'), NULL, 1, 'Nhan vien', 31, 1300, NULL);
INSERT INTO s_emp VALUES (6, 'Hoang', 'Khai', 'hkhai', TO_DATE('14/05/1990','DD/MM/YYYY'), NULL, 1, 'Sale Rep', 31, 1500, 10);
INSERT INTO s_emp VALUES (7, 'David', 'Silva', 'dsilva', SYSDATE-1000, NULL, 1, 'Sale Rep', 50, 1600, 15);
INSERT INTO s_emp VALUES (8, 'Sarah', 'Connor', 'sconnor', SYSDATE-900, NULL, 1, 'Nhan vien', 50, 1400, NULL);
INSERT INTO s_emp VALUES (9, 'Honda', 'Suzuki', 'hsuzuki', SYSDATE-800, NULL, 1, 'Nhan vien', 60, 1700, NULL);
INSERT INTO s_emp VALUES (10, 'Kim', 'Soo', 'ksoo', SYSDATE-700, NULL, 1, 'Nhan vien', 31, 1350, NULL);
INSERT INTO s_emp VALUES (11, 'Tran', 'Binh', 'tbinh', SYSDATE-600, NULL, 1, 'Nhan vien', 42, 1100, NULL);
INSERT INTO s_emp VALUES (12, 'Le', 'Quang', 'lquang', SYSDATE-500, NULL, 1, 'Nhan vien', 42, 1200, NULL);
INSERT INTO s_emp VALUES (13, 'Bui', 'Tien', 'btien', SYSDATE-400, NULL, 1, 'Nhan vien', 42, 1450, NULL);
INSERT INTO s_emp VALUES (14, 'Messi', 'Lionel', 'mlessi', SYSDATE-300, NULL, 1, 'Sale Rep', 90, 2500, 20);
INSERT INTO s_emp VALUES (15, 'Ronaldo', 'Cris', 'cronal', SYSDATE-200, NULL, 1, 'Sale Rep', 10, 2400, 15);
INSERT INTO s_emp VALUES (16, 'Mbappe', 'Kylian', 'kmbap', SYSDATE-100, NULL, 1, 'Nhan vien', 10, 1800, NULL);
INSERT INTO s_emp VALUES (17, 'Neymar', 'DaSilva', 'ndasil', SYSDATE-50, NULL, 1, 'Nhan vien', 90, 1900, NULL);
INSERT INTO s_emp VALUES (18, 'Haaland', 'Erling', 'ehaal', SYSDATE-40, NULL, 1, 'Nhan vien', 80, 1500, NULL);
INSERT INTO s_emp VALUES (19, 'Kante', 'Ngolo', 'nkante', SYSDATE-30, NULL, 1, 'Nhan vien', 10, 1600, NULL);
INSERT INTO s_emp VALUES (20, 'Gomez', 'Selena', 'sgomez', SYSDATE-20, NULL, 1, 'Nhan vien', 10, 1700, NULL);
INSERT INTO s_emp VALUES (21, 'Swift', 'Taylor', 'tswift', SYSDATE-10, NULL, 1, 'Nhan vien', 10, 1800, NULL);
INSERT INTO s_emp VALUES (22, 'Bieber', 'Justin', 'jbieb', SYSDATE-5, NULL, 1, 'Nhan vien', 10, 1200, NULL);

-- Nhân viên báo cáo cho cấp dưới 
INSERT INTO s_emp VALUES (23, 'Do', 'Khoa', 'dkhoa', SYSDATE-300, NULL, 2, 'Ky thuat', 42, 1100, NULL);
INSERT INTO s_emp VALUES (24, 'Vu', 'Nhom', 'vnhom', SYSDATE-200, NULL, 2, 'Ky thuat', 42, 1150, NULL);
INSERT INTO s_emp VALUES (25, 'Steve', 'Jobs', 'sjobs', SYSDATE-100, NULL, 3, 'Marketing', 50, 1900, NULL);
SELECT * FROM s_emp;

INSERT INTO s_warehouse VALUES (1, 4, 'Khu CNC', 'HCM', 'HCM', 'VN', '70000', '0909123456', 2);
INSERT INTO s_warehouse VALUES (2, 1, '123 NY St', 'New York', 'NY', 'USA', '10001', '123456789', 3);
INSERT INTO s_warehouse VALUES (3, 5, 'Tokyo Tower', 'Tokyo', 'TK', 'Japan', '100-00', '987654321', 9);
INSERT INTO s_warehouse VALUES (4, 9, 'London Eye', 'London', 'LDN', 'UK', 'EC1A', '55555555', 7);
INSERT INTO s_warehouse VALUES (5, 14, 'Sydney Opera', 'Sydney', 'NSW', 'AUS', '2000', '66666666', 1);
SELECT * FROM s_warehouse;

INSERT INTO s_customer VALUES (100, 'Cong ty VIP', '0123', 'Q1', 'HCM', 'HCM', 'VN', '70000', 'Excellent', 6, 4, NULL);
INSERT INTO s_customer VALUES (101, 'Khach B', '0456', 'Q2', 'HCM', 'HCM', 'VN', '70000', 'Good', 6, 4, NULL);
INSERT INTO s_customer VALUES (102, 'Customer US 1', '111', 'NY', 'NY', 'NY', 'USA', '10001', 'Fair', 7, 1, NULL);
INSERT INTO s_customer VALUES (103, 'Customer US 2', '222', 'LA', 'LA', 'CA', 'USA', '90001', 'Good', 7, 1, NULL);
INSERT INTO s_customer VALUES (104, 'Khach JP', '333', 'Tokyo', 'TK', 'TK', 'Japan', '100', 'Excellent', 14, 5, NULL);
INSERT INTO s_customer VALUES (105, 'Khach UK 1', '444', 'London', 'LDN', 'LDN', 'UK', 'EC', 'Fair', 15, 9, NULL);
INSERT INTO s_customer VALUES (106, 'Khach KR', '555', 'Seoul', 'SE', 'SE', 'Korea', '011', 'Good', 14, 6, NULL);
INSERT INTO s_customer VALUES (107, 'Khach TH', '666', 'BKK', 'BKK', 'BKK', 'Thai', '10', 'Poor', 6, 7, NULL);
INSERT INTO s_customer VALUES (108, 'Khach SG', '777', 'Marina', 'SG', 'SG', 'Sing', '001', 'Good', 6, 8, NULL);
INSERT INTO s_customer VALUES (109, 'Khach FR', '888', 'Paris', 'PR', 'PR', 'France', '75', 'Excellent', 15, 10, NULL);
INSERT INTO s_customer VALUES (110, 'Khach DE', '999', 'Berlin', 'BL', 'BL', 'Germany', '101', 'Good', 15, 11, NULL);
INSERT INTO s_customer VALUES (111, 'Khach IT', '000', 'Rome', 'RM', 'RM', 'Italy', '001', 'Fair', 14, 12, NULL);
INSERT INTO s_customer VALUES (112, 'Khach ES', '121', 'Madrid', 'MD', 'MD', 'Spain', '28', 'Good', 14, 13, NULL);
INSERT INTO s_customer VALUES (113, 'Khach AU', '313', 'Sydney', 'SY', 'SY', 'Aus', '2000', 'Excellent', 7, 14, NULL);
-- Khách chưa từng mua hàng 
INSERT INTO s_customer VALUES (999, 'Khach Hang Ao', '9999', 'Hư Không', 'No', 'No', 'No', '000', 'Poor', 6, 4, 'Chua mua gi');
SELECT * FROM s_customer;

INSERT INTO s_product VALUES (10, 'Pro Series Max', 'Dien thoai cao cap', 1, 1, 1000, 'Cai');
INSERT INTO s_product VALUES (20, 'Mountain Bicycle', 'Xe dap dia hinh bicycle', 2, 2, 250, 'Chiec');
INSERT INTO s_product VALUES (30, 'Water Ski Board', 'Van truot nuoc ski', NULL, NULL, 300, 'Bo');
INSERT INTO s_product VALUES (40, 'Pro Laptop', 'May tinh xach tay Pro', NULL, NULL, 1500, 'Cai');
INSERT INTO s_product VALUES (50, 'City Bicycle', 'Xe dap the thao bicycle', NULL, NULL, 200, 'Chiec');
INSERT INTO s_product VALUES (60, 'Snow Ski Shoes', 'Giay truot tuyet ski', NULL, NULL, 150, 'Doi');
INSERT INTO s_product VALUES (70, 'Tai nghe Bluetooth', 'Tai nghe khong day', NULL, NULL, 50, 'Cai');
INSERT INTO s_product VALUES (80, 'Ban Phim Co', 'Ban phim gaming', NULL, NULL, 80, 'Cai');
INSERT INTO s_product VALUES (90, 'Chuot Khong Day', 'Chuot van phong', NULL, NULL, 20, 'Cai');
INSERT INTO s_product VALUES (100, 'Man Hinh 24 inch', 'Man hinh may tinh', NULL, NULL, 150, 'Cai');
SELECT * FROM s_product;

INSERT INTO s_ord VALUES (101, 100, SYSDATE-20, SYSDATE-15, 6, 200000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (102, 100, SYSDATE-18, SYSDATE-12, 6, 150000, 'CREDIT', 'Y');
INSERT INTO s_ord VALUES (103, 100, SYSDATE-10, SYSDATE-5, 6, 50000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (104, 100, SYSDATE-2, NULL, 6, 300000, 'CREDIT', 'N');
INSERT INTO s_ord VALUES (105, 101, SYSDATE-15, SYSDATE-10, 6, 120000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (106, 101, SYSDATE-5, NULL, 6, 80000, 'CREDIT', 'N');
INSERT INTO s_ord VALUES (107, 102, SYSDATE-30, SYSDATE-20, 7, 50000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (108, 103, SYSDATE-25, SYSDATE-20, 7, 45000, 'CREDIT', 'Y');
INSERT INTO s_ord VALUES (109, 104, SYSDATE-10, SYSDATE-5, 14, 90000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (110, 105, SYSDATE-8, SYSDATE-2, 15, 110000, 'CREDIT', 'Y');
INSERT INTO s_ord VALUES (111, 106, SYSDATE-12, SYSDATE-7, 14, 60000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (112, 107, SYSDATE-6, NULL, 6, 40000, 'CREDIT', 'N');
INSERT INTO s_ord VALUES (113, 108, SYSDATE-4, NULL, 6, 75000, 'CASH', 'N');
INSERT INTO s_ord VALUES (114, 109, SYSDATE-3, NULL, 15, 105000, 'CREDIT', 'N');
INSERT INTO s_ord VALUES (115, 110, SYSDATE-1, NULL, 15, 30000, 'CASH', 'N');
SELECT * FROM s_ord;

INSERT INTO s_item VALUES (101, 1, 10, 1000, 100, 100);
INSERT INTO s_item VALUES (101, 2, 40, 1500, 50, 50);
INSERT INTO s_item VALUES (102, 1, 20, 250, 200, 200);
INSERT INTO s_item VALUES (103, 1, 30, 300, 100, 100);
INSERT INTO s_item VALUES (104, 1, 10, 1000, 300, 0);
INSERT INTO s_item VALUES (105, 1, 50, 200, 600, 600);
INSERT INTO s_item VALUES (106, 1, 60, 150, 400, 0);
INSERT INTO s_item VALUES (107, 1, 70, 50, 1000, 1000);
INSERT INTO s_item VALUES (108, 1, 80, 80, 500, 500);
INSERT INTO s_item VALUES (109, 1, 90, 20, 4500, 4500);
SELECT * FROM s_item;

INSERT INTO s_inventory VALUES (10, 1, 5000, 1000, 10000, NULL, SYSDATE+10);
INSERT INTO s_inventory VALUES (20, 1, 2000, 500, 5000, NULL, SYSDATE+5);
INSERT INTO s_inventory VALUES (30, 2, 1000, 200, 3000, NULL, SYSDATE+15);
INSERT INTO s_inventory VALUES (40, 3, 3000, 800, 8000, NULL, SYSDATE+2);
INSERT INTO s_inventory VALUES (50, 4, 1500, 300, 4000, NULL, SYSDATE+7);
INSERT INTO s_inventory VALUES (60, 5, 800, 150, 2000, NULL, SYSDATE+12);
SELECT * FROM s_inventory;

--BÀI 2
--Câu 1:
SELECT name AS "Ten khach hang", 
       id AS "Ma khach hang" 
FROM s_customer 
ORDER BY id DESC;

--Câu 2:
SELECT first_name || ' ' || last_name AS "Employees", 
       dept_id 
FROM s_emp 
WHERE dept_id IN (10, 50) 
ORDER BY first_name;

--Câu 3:
SELECT last_name, first_name 
FROM s_emp 
WHERE first_name LIKE '%S%' 
   OR last_name LIKE '%S%';
   
--Câu 4: 
SELECT userid, start_date 
FROM s_emp 
WHERE start_date BETWEEN TO_DATE('14/05/1990','DD/MM/YYYY') 
                     AND TO_DATE('26/05/1991','DD/MM/YYYY');
                     
--Câu 5:
SELECT last_name, salary 
FROM s_emp 
WHERE salary BETWEEN 1000 AND 2000;

--Câu 6:
SELECT last_name || ' ' || first_name AS "Employee Name", 
       salary AS "Monthly Salary" 
FROM s_emp 
WHERE dept_id IN (31, 42, 50) 
  AND salary > 1350;
  
--Câu 7:
SELECT last_name, start_date 
FROM s_emp 
WHERE TO_CHAR(start_date, 'YYYY') = '1991';

--Câu 8:
SELECT last_name, first_name 
FROM s_emp 
WHERE id NOT IN (SELECT DISTINCT manager_id 
                 FROM s_emp 
                 WHERE manager_id IS NOT NULL);
                 
--Câu 9:
SELECT name 
FROM s_product 
WHERE name LIKE 'Pro%' 
ORDER BY name ASC;

--Câu 10:
SELECT name, short_desc 
FROM s_product 
WHERE LOWER(short_desc) LIKE '%bicycle%';

--Câu 11:
SELECT short_desc 
FROM s_product;

--Câu 12:
SELECT last_name || ' ' || first_name || ' (' || title || ')' AS "Nhan vien" 
FROM s_emp;

--Bài 3
--Câu 1:
SELECT id, 
       last_name, 
       ROUND(salary * 1.15, 2) AS "Luong moi" 
FROM s_emp;

--Câu 2:
SELECT last_name, 
       start_date, 
       TO_CHAR(
           NEXT_DAY(ADD_MONTHS(start_date, 6), 'MONDAY'), 
           'Ddspth "of" Month YYYY'
       ) AS "Ngay xet tang luong" 
FROM s_emp;

--Câu 3:
SELECT name 
FROM s_product 
WHERE LOWER(name) LIKE '%ski%';

--Câu 4:
SELECT last_name, 
       ROUND(MONTHS_BETWEEN(SYSDATE, start_date)) AS "So thang tham nien" 
FROM s_emp 
ORDER BY MONTHS_BETWEEN(SYSDATE, start_date) ASC;

--Câu 5:
SELECT COUNT(DISTINCT manager_id) AS "So nguoi quan ly" 
FROM s_emp 
WHERE manager_id IS NOT NULL;

--Câu 6:
SELECT MAX(total) AS "Highest", 
       MIN(total) AS "Lowest" 
FROM s_ord;

--Bài 4:
--Câu 1;
SELECT p.name, 
       p.id, 
       i.quantity AS "ORDERED" 
FROM s_product p, s_item i 
WHERE p.id = i.product_id 
  AND i.ord_id = 101;
  
--Câu 2;
SELECT c.id AS "Ma khach hang", 
       o.id AS "Ma don hang" 
FROM s_customer c, s_ord o 
WHERE c.id = o.customer_id(+) 
ORDER BY c.id;
---cách 2:
SELECT c.id AS "Ma khach hang", 
       o.id AS "Ma don hang" 
FROM s_customer c LEFT JOIN s_ord o 
  ON c.id = o.customer_id 
ORDER BY c.id;

--Câu 3:
SELECT o.customer_id, 
       i.product_id, 
       i.quantity 
FROM s_ord o, s_item i 
WHERE o.id = i.ord_id 
  AND o.total > 100000;
  
--Bài 5:
--Câu 1:
SELECT manager_id AS "Ma quan ly", 
       COUNT(id) AS "So nhan vien" 
FROM s_emp 
WHERE manager_id IS NOT NULL 
GROUP BY manager_id 
ORDER BY manager_id;

--Câu 2:
SELECT manager_id AS "Ma quan ly", 
       COUNT(id) AS "So nhan vien" 
FROM s_emp 
WHERE manager_id IS NOT NULL 
GROUP BY manager_id 
HAVING COUNT(id) >= 20;

--Câu 3:
SELECT r.id AS "Ma vung", 
       r.name AS "Ten vung", 
       COUNT(d.id) AS "So phong ban" 
FROM s_region r, s_dept d 
WHERE r.id = d.region_id 
GROUP BY r.id, r.name 
ORDER BY r.id;

--Câu 4:
SELECT c.name AS "Ten khach hang", 
       COUNT(o.id) AS "So don dat hang" 
FROM s_customer c, s_ord o 
WHERE c.id = o.customer_id 
GROUP BY c.id, c.name 
ORDER BY c.name;

--Câu 5:
SELECT c.name, COUNT(o.id) AS "So don hang" 
FROM s_customer c, s_ord o 
WHERE c.id = o.customer_id 
GROUP BY c.id, c.name 
HAVING COUNT(o.id) = ( 
    SELECT MAX(COUNT(id)) 
    FROM s_ord 
    GROUP BY customer_id 
);

--Câu 6:
SELECT c.name, SUM(o.total) AS "Tong tien" 
FROM s_customer c, s_ord o 
WHERE c.id = o.customer_id 
GROUP BY c.id, c.name 
HAVING SUM(o.total) = ( 
    SELECT MAX(SUM(total)) 
    FROM s_ord 
    GROUP BY customer_id 
);

--Bài 6:
--Câu 1:
SELECT last_name, 
       first_name, 
       start_date 
FROM s_emp 
WHERE dept_id IN (
    SELECT dept_id 
    FROM s_emp 
    WHERE first_name = 'Lan'
) 
AND first_name != 'Lan';

--Câu 2:
SELECT id, 
       last_name, 
       first_name, 
       userid 
FROM s_emp 
WHERE salary > (
    SELECT AVG(salary) 
    FROM s_emp
);

--Câu 3:
SELECT id, 
       last_name, 
       first_name 
FROM s_emp 
WHERE salary > (
    SELECT AVG(salary) 
    FROM s_emp
) 
AND (UPPER(first_name) LIKE '%L%' OR UPPER(last_name) LIKE '%L%');

--Câu 4:
SELECT c.name 
FROM s_customer c 
WHERE NOT EXISTS (
    SELECT 1 
    FROM s_ord o 
    WHERE o.customer_id = c.id
);