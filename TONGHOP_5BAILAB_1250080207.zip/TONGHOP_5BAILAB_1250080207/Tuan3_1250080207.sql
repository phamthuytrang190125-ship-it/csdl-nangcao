SET SERVEROUTPUT ON;

--Tạo bảng 
CREATE TABLE COURSE (
    CourseNo NUMBER(8,0) PRIMARY KEY,
    Description VARCHAR2(50),
    Cost NUMBER(9,2),
    Prerequisite NUMBER(8,0) REFERENCES COURSE(CourseNo),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);


CREATE TABLE INSTRUCTOR (
    InstructorID NUMBER(8,0) PRIMARY KEY,
    Salutation VARCHAR2(5),
    FirstName VARCHAR2(25),
    LastName VARCHAR2(25),
    Address VARCHAR2(50),
    Phone VARCHAR2(15),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);


CREATE TABLE CLASS (
    ClassID NUMBER(8,0) PRIMARY KEY,
    CourseNo NUMBER(8,0) NOT NULL REFERENCES COURSE(CourseNo),
    ClassNo NUMBER(3) NOT NULL,
    StartDateTime DATE,
    Location VARCHAR2(50),
    InstructorID NUMBER(8,0) NOT NULL REFERENCES INSTRUCTOR(InstructorID),
    Capacity NUMBER(3,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);


CREATE TABLE STUDENT (
    StudentID NUMBER(8,0) PRIMARY KEY,
    Salutation VARCHAR2(5),
    FirstName VARCHAR2(25),
    LastName VARCHAR2(25) NOT NULL,
    Address VARCHAR2(50),
    Phone VARCHAR2(15),
    Employer VARCHAR2(50),
    RegistrationDate DATE NOT NULL,
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);

CREATE TABLE ENROLLMENT (
    StudentID NUMBER(8,0) REFERENCES STUDENT(StudentID),
    ClassID NUMBER(8,0) REFERENCES CLASS(ClassID),
    EnrollDate DATE NOT NULL,
    FinalGrade NUMBER(3,0),
    RegistrationDate DATE NOT NULL,
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,
    PRIMARY KEY (StudentID, ClassID)
);

CREATE TABLE GRADE (
    StudentID NUMBER(8,0) REFERENCES STUDENT(StudentID),
    ClassID NUMBER(8,0) REFERENCES CLASS(ClassID),
    Grade NUMBER(3) NOT NULL,
    Comments VARCHAR2(2000),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,
    PRIMARY KEY (StudentID, ClassID)
);
-- 1. Tạo Giảng viên (Mã 1)
INSERT INTO instructor (instructorid, firstname, lastname, createdby, createddate, modifiedby, modifieddate) 
VALUES (1, 'Huynh', 'Kom', USER, SYSDATE, USER, SYSDATE);

-- 2. Tạo Môn học (Mã 100)
INSERT INTO course (courseno, description, cost, createdby, createddate, modifiedby, modifieddate) 
VALUES (100, 'Database', 500, USER, SYSDATE, USER, SYSDATE);

-- 3. Tạo Lớp học (Mã 100, Môn 100, GV 1, Sức chứa = 2)
INSERT INTO class (classid, courseno, classno, instructorid, capacity, createdby, createddate, modifiedby, modifieddate) 
VALUES (100, 100, 1, 1, 2, USER, SYSDATE, USER, SYSDATE);

-- 4. Tạo Sinh viên 1 (Mã 999)
INSERT INTO student (studentid, firstname, lastname, registrationdate, createdby, createddate, modifiedby, modifieddate) 
VALUES (999, 'Trang', 'Pham', SYSDATE, USER, SYSDATE, USER, SYSDATE);

-- 5. Tạo Sinh viên 2 (Mã 998)
INSERT INTO student (studentid, firstname, lastname, registrationdate, createdby, createddate, modifiedby, modifieddate) 
VALUES (998, 'Nguyen', 'Van A', SYSDATE, USER, SYSDATE, USER, SYSDATE);

-- 6. Tạo Sinh viên 3 (Mã 997)
INSERT INTO student (studentid, firstname, lastname, registrationdate, createdby, createddate, modifiedby, modifieddate) 
VALUES (997, 'Le', 'Thi B', SYSDATE, USER, SYSDATE, USER, SYSDATE);

-- CHỐT DỮ LIỆU VÀO Ổ CỨNG
COMMIT;

--Bài 1:
--1. Viết các lệnh thực hiện những công việc sau:
--a. Tạo một bảng Cau1 với 2 cột ID (number) và NAME (varchar2(20)).
CREATE TABLE Cau1 (
    ID NUMBER,
    NAME VARCHAR2(20)
);

--b. Tạo một sequence Cau1Seq với bước tăng là 5.
CREATE SEQUENCE Cau1Seq
START WITH 5
INCREMENT BY 5;

--c. Khai báo 2 biến v_name và v_id. Biến v_name, v_id. dùng để chứa giá trị họ, 
--mãcủa sinh viên được thêm vào.
SET SERVEROUTPUT ON;
DECLARE
    v_name VARCHAR2(50);
    v_id   NUMBER;
BEGIN
    
-- [d] Thêm sinh viên đăng ký nhiều môn nhất
    SELECT firstname || ' ' || lastname INTO v_name
    FROM student
    WHERE studentid = (
        SELECT studentid FROM enrollment
        GROUP BY studentid
        HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM enrollment GROUP BY studentid)
        FETCH FIRST 1 ROWS ONLY
    );
    
    INSERT INTO Cau1 (ID, NAME) VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_a;  -- Savepoint A
    
    -- [e] Thêm sinh viên đăng ký ít môn nhất
    SELECT firstname || ' ' || lastname INTO v_name
    FROM student
    WHERE studentid = (
        SELECT studentid FROM enrollment
        GROUP BY studentid
        HAVING COUNT(*) = (SELECT MIN(COUNT(*)) FROM enrollment GROUP BY studentid)
        FETCH FIRST 1 ROWS ONLY
    );
    
    INSERT INTO Cau1 (ID, NAME) VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_b;  -- Savepoint B
    
    -- [f] Thêm giáo viên dạy nhiều lớp nhất
    SELECT i.firstname || ' ' || i.lastname INTO v_name
    FROM instructor i
    WHERE i.instructorid = (
        SELECT instructorid FROM class
        GROUP BY instructorid
        HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM class GROUP BY instructorid)
        FETCH FIRST 1 ROWS ONLY
    );
    
    INSERT INTO Cau1 (ID, NAME) VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_c;  -- Savepoint C
    
    -- [g] SELECT INTO: lấy ID của giáo viên vừa thêm vào biến v_id
    SELECT ID INTO v_id FROM Cau1 WHERE NAME = v_name;
    DBMS_OUTPUT.PUT_LINE('ID giao vien nhieu lop: ' || v_id);
    
    -- [h] Rollback giáo viên nhiều lớp (về Savepoint B)
    ROLLBACK TO sp_b;
    
    -- [i] Thêm giáo viên ít lớp nhất, dùng v_id đã lưu
    SELECT i.firstname || ' ' || i.lastname INTO v_name
    FROM instructor i
    WHERE i.instructorid = (
        SELECT instructorid FROM class
        GROUP BY instructorid
        HAVING COUNT(*) = (SELECT MIN(COUNT(*)) FROM class GROUP BY instructorid)
        FETCH FIRST 1 ROWS ONLY
    );
    
    INSERT INTO Cau1 (ID, NAME) VALUES (v_id, v_name);
    
    -- [j] Thêm lại giáo viên nhiều lớp, dùng sequence
    SELECT i.firstname || ' ' || i.lastname INTO v_name
    FROM instructor i
    WHERE i.instructorid = (
        SELECT instructorid FROM class
        GROUP BY instructorid
        HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM class GROUP BY instructorid)
        FETCH FIRST 1 ROWS ONLY
    );
    
    INSERT INTO Cau1 (ID, NAME) VALUES (Cau1Seq.NEXTVAL, v_name);
    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('Hoan tat! Kiem tra: SELECT * FROM Cau1;');
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Khong tim thay du lieu! (Do bang chua co data)');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
        ROLLBACK;
END;
/

--2: Nhập mã sinh viên - kiểm tra tồn tại → hiển thị thông tin; không tồn tại → thêm sinh viên mới
SET SERVEROUTPUT ON;

DECLARE
    v_sid       NUMBER        := &ma_sinh_vien;
    v_fname     VARCHAR2(25)  := '&ho_sinh_vien';
    v_lname     VARCHAR2(25)  := '&ten_sinh_vien';
    v_addr      VARCHAR2(50)  := '&dia_chi';
    v_found     VARCHAR2(50);
    v_classes NUMBER;
BEGIN
    -- Thu tim sinh vien theo ma vua nhap
    SELECT firstname || ' ' || lastname
    INTO   v_found
    FROM   student
    WHERE  studentid = v_sid;

    -- Neu tim thay: dem so lop dang hoc
    SELECT COUNT(*)
    INTO   v_classes
    FROM   enrollment
    WHERE  studentid = v_sid;

    DBMS_OUTPUT.PUT_LINE('Ho ten: ' || v_found);
    DBMS_OUTPUT.PUT_LINE('So lop dang hoc: ' || v_classes);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        -- Sinh vien chua ton tai: them moi
        DBMS_OUTPUT.PUT_LINE('Sinh vien chua ton tai. Dang them moi...');
        INSERT INTO student (studentid, firstname, lastname, address,
                             registrationdate, createdby, createddate,
                             modifiedby, modifieddate)
        VALUES (v_sid, v_fname, v_lname, v_addr,
                SYSDATE, USER, SYSDATE, USER, SYSDATE);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Da them sinh vien moi: ' || v_fname || ' ' || v_lname);
END;
/

--Bài 2: Các cấu trúc điều khiển
--Câu 1: Nhập mã giáo viên → đếm số lớp đang dạy → IF ≥ 5: thông báo nghỉ ngơi,
--ELSE in số lớp
SET SERVEROUTPUT ON;
DECLARE
    v_instructor_id NUMBER := &ma_giao_vien;
    v_so_lop        NUMBER;
BEGIN
    -- Dem so lop giao vien dang day
    SELECT COUNT(*)
    INTO v_so_lop
    FROM   class
    WHERE  instructorid = v_instructor_id;

    -- Phan nhanh theo ket qua
    IF v_so_lop >= 5 THEN
        DBMS_OUTPUT.PUT_LINE('Giao vien nay nen nghi ngoi!');
    ELSE
        DBMS_OUTPUT.PUT_LINE('So lop giao vien dang day: ' || v_so_lop);
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Khong tim thay giao vien co ma: ' || v_instructor_id);
END;
/

--Câu 2:Nhập mã sinh viên + mã lớp → in điểm chữ bằng CASE; xử lý lỗi khi mã
--không tồn tại
SET SERVEROUTPUT ON;
DECLARE
    v_sid     NUMBER := &ma_sinh_vien;
    v_cid     NUMBER := &ma_lop;
    v_score   NUMBER;
    v_grade   VARCHAR2(2);
    v_check   NUMBER;
BEGIN
    -- Kiem tra sinh vien ton tai
    SELECT COUNT(*) INTO v_check
    FROM student WHERE studentid = v_sid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma sinh vien ' || v_sid || ' khong ton tai!');
        RETURN;
    END IF;

    -- Kiem tra lop ton tai
    SELECT COUNT(*) INTO v_check
    FROM   class WHERE classid = v_cid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma lop ' || v_cid || ' khong ton tai!');
        RETURN;
    END IF;

    -- Lay diem cua sinh vien trong lop
    SELECT finalgrade
    INTO v_score
    FROM   enrollment
    WHERE studentid = v_sid AND classid = v_cid;

    -- Quy doi diem so sang diem chu bang CASE
    CASE
        WHEN v_score >= 90 THEN v_grade := 'A';
        WHEN v_score >= 80 THEN v_grade := 'B';
        WHEN v_score >= 70 THEN v_grade := 'C';
        WHEN v_score >= 50 THEN v_grade := 'D';
        ELSE v_grade := 'F';
    END CASE;

    DBMS_OUTPUT.PUT_LINE('Diem so: ' || v_score || ' -> Diem chu: ' || v_grade);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Sinh vien chua dang ky lop nay hoac chua co diem!');
END;
/

--BÀI 3: Cursor - Duyệt Tập Kết Quả
SET SERVEROUTPUT ON;

DECLARE
    -- Cursor 1: Duyet tung mon hoc
    CURSOR cur_course IS
        SELECT courseno, description
        FROM   course
        ORDER  BY courseno;

    -- Cursor 2: Lay lop hoc cua mot mon (co doi so)
    CURSOR cur_class (p_courseno NUMBER) IS
        SELECT c.classno,
               COUNT(e.studentid) AS so_sv
        FROM   class c
        LEFT   JOIN enrollment e ON c.classid = e.classid
        WHERE  c.courseno = p_courseno
        GROUP BY c.classno
        ORDER BY c.classno;

    v_courseno  course.courseno%TYPE;
    v_desc      course.description%TYPE;
    v_classno   class.classno%TYPE;
    v_count     NUMBER;

BEGIN
    -- Duyet cursor ngoai: tung mon hoc
    OPEN cur_course;
    LOOP
        FETCH cur_course INTO v_courseno, v_desc;
        EXIT WHEN cur_course%NOTFOUND;

        -- In ten mon hoc
        DBMS_OUTPUT.PUT_LINE(v_courseno || ' ' || v_desc);

        -- Mo cursor trong voi doi so la ma mon hoc hien tai
        OPEN cur_class(v_courseno);
        LOOP
            FETCH cur_class INTO v_classno, v_count;
            EXIT WHEN cur_class%NOTFOUND;

            DBMS_OUTPUT.PUT_LINE('   Lop: ' || v_classno || ' co so luong sinh vien dang ki: ' || v_count);
        END LOOP;
        CLOSE cur_class;

    END LOOP;
    CLOSE cur_course;

EXCEPTION
    WHEN OTHERS THEN
        IF cur_course%ISOPEN THEN CLOSE cur_course; END IF;
        IF cur_class%ISOPEN THEN CLOSE cur_class; END IF;
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
END;
/

--BÀI 4: Thủ Tục (Procedure) Và Hàm (Function)
--Câu 4.1a: Thủ tục find_sname - nhận mã SV, trả về FirstName và LastName
CREATE OR REPLACE PROCEDURE find_sname
(i_student_id IN student.studentid%TYPE,
 o_first_name OUT student.firstname%TYPE,
 o_last_name OUT student.lastname%TYPE)
IS
BEGIN
    SELECT firstname, lastname
    INTO o_first_name, o_last_name
    FROM student
    WHERE studentid = i_student_id;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        o_first_name := NULL;
        o_last_name := NULL;
        DBMS_OUTPUT.PUT_LINE('Khong tim thay sinh vien ID: ' || i_student_id);
END find_sname;
/

--Câu 4.1b: Thủ tục print_student_name nhận mã SV, gọi find_sname và in tên ra màn hình
CREATE OR REPLACE PROCEDURE print_student_name
(i_student_id IN student.studentid%TYPE)
IS
    v_first student.firstname%TYPE;
    v_last  student.lastname%TYPE;
BEGIN
    -- Goi thu tuc find_sname da co san
    find_sname(i_student_id, v_first, v_last);

    IF v_first IS NOT NULL OR v_last IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Ho ten sinh vien: ' || v_first || ' ' || v_last);
    END IF;
END print_student_name;
/

SET SERVEROUTPUT ON;
BEGIN
    print_student_name(101);
END;
/

--Câu 4.2: Thủ tục Discount - giảm 5% cho môn học có hơn 15 sinh viên đăng ký
CREATE OR REPLACE PROCEDURE Discount
IS
BEGIN
    FOR rec IN (
        SELECT c.courseno, c.description, c.cost
        FROM course c
        WHERE (SELECT COUNT(*) FROM enrollment e
               JOIN class cl ON e.classid = cl.classid
               WHERE cl.courseno = c.courseno) > 15
    ) LOOP
        -- Giam gia 5%
        UPDATE course
        SET cost = cost * 0.95
        WHERE courseno = rec.courseno;

        DBMS_OUTPUT.PUT_LINE('Da giam gia mon hoc: ' || rec.description ||
                             ' | Gia cu: ' || rec.cost ||
                             ' | Gia moi: ' || ROUND(rec.cost * 0.95, 2));
    END LOOP;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Hoan tat giam gia.');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
END Discount;
/
-- Goi thu tuc:
SET SERVEROUTPUT ON;
BEGIN 
    Discount; 
END;
/

--Câu 4.3: Hàm Total_cost_for_student - trả về tổng chi phí một sinh viên phải trả;
--NULL nếu không tồn tại
CREATE OR REPLACE FUNCTION Total_cost_for_student
(p_student_id IN student.studentid%TYPE)
RETURN NUMBER
IS
    v_total NUMBER;
    v_check NUMBER;
BEGIN
    -- Kiem tra sinh vien co ton tai khong
    SELECT COUNT(*) INTO v_check
    FROM student WHERE studentid = p_student_id;

    IF v_check = 0 THEN
        RETURN NULL; -- Sinh vien khong ton tai
    END IF;

    -- Tinh tong chi phi: sum(cost cua tung mon da dang ky)
    SELECT NVL(SUM(co.cost), 0)
    INTO v_total
    FROM enrollment e
    JOIN class cl ON e.classid = cl.classid
    JOIN course co ON cl.courseno = co.courseno
    WHERE e.studentid = p_student_id;

    RETURN v_total;
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END Total_cost_for_student;
/

SET SERVEROUTPUT ON;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Tong chi phi: ' || Total_cost_for_student(101));
END;
/

--BÀI 5: Trigger
--Câu 5.1: Trigger tự động điền created_by, created_date, modified_by,
-- modified_date cho tất cả các bảng
--Trigger mẫu cho bảng COURSE:
CREATE OR REPLACE TRIGGER trg_course_audit
BEFORE INSERT OR UPDATE ON course
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.createdby := USER;
        :NEW.createddate := SYSDATE;
    END IF;
    -- Luon cap nhat modified (ca khi INSERT lan UPDATE)
    :NEW.modifiedby := USER;
    :NEW.modifieddate := SYSDATE;
END trg_course_audit;
/

--Trigger tương tự cho bảng CLASS:
CREATE OR REPLACE TRIGGER trg_class_audit
BEFORE INSERT OR UPDATE ON class
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.createdby := USER;
        :NEW.createddate := SYSDATE;
    END IF;
    :NEW.modifiedby := USER;
    :NEW.modifieddate := SYSDATE;
END trg_class_audit;
/

--Trigger cho bảng STUDENT:
CREATE OR REPLACE TRIGGER trg_student_audit
BEFORE INSERT OR UPDATE ON student 
FOR EACH ROW
BEGIN
    IF INSERTING THEN 
        :NEW.createdby := USER; 
        :NEW.createddate := SYSDATE; 
    END IF;
    :NEW.modifiedby := USER; 
    :NEW.modifieddate := SYSDATE;
END;
/

--Trigger cho bảng ENROLLMENT:
CREATE OR REPLACE TRIGGER trg_enrollment_audit
BEFORE INSERT OR UPDATE ON enrollment 
FOR EACH ROW
BEGIN
    IF INSERTING THEN 
        :NEW.createdby := USER; 
        :NEW.createddate := SYSDATE; 
    END IF;
    :NEW.modifiedby := USER; 
    :NEW.modifieddate := SYSDATE;
END;
/

--Trigger cho bảng INSTRUCTOR:
CREATE OR REPLACE TRIGGER trg_instructor_audit
BEFORE INSERT OR UPDATE ON instructor 
FOR EACH ROW
BEGIN
    IF INSERTING THEN 
        :NEW.createdby := USER; 
        :NEW.createddate := SYSDATE; 
    END IF;
    :NEW.modifiedby := USER; 
    :NEW.modifieddate := SYSDATE;
END;
/

--Trigger cho bảng GRADE:
CREATE OR REPLACE TRIGGER trg_grade_audit
BEFORE INSERT OR UPDATE ON grade 
FOR EACH ROW
BEGIN
    IF INSERTING THEN 
        :NEW.createdby := USER; 
        :NEW.createddate := SYSDATE; 
    END IF;
    :NEW.modifiedby := USER; 
    :NEW.modifieddate := SYSDATE;
END;
/

--Câu 5.2: Trigger kiểm tra: mỗi sinh viên không được đăng ký quá 3 lớp học
CREATE OR REPLACE TRIGGER trg_max_enrollment
BEFORE INSERT ON enrollment
FOR EACH ROW
DECLARE
    v_so_lop NUMBER;
BEGIN
    -- Dem so lop sinh vien nay dang dang ky [cite: 991-996]
    SELECT COUNT(*)
    INTO v_so_lop
    FROM enrollment
    WHERE studentid = :NEW.studentid;

    -- Neu da co 3 lop tro len thi tu choi [cite: 997-1005]
    IF v_so_lop >= 3 THEN
        RAISE_APPLICATION_ERROR(
            -20001,
            'Sinh vien ' || :NEW.studentid || ' da dang ky du 3 lop! Khong the dang ky them.'
        );
    END IF;
END trg_max_enrollment;
/

-- Kiem tra trigger:
-- Gia su sinh vien 101 da co 3 lop, thu them lop thu 4:
INSERT INTO enrollment (studentid, classid, enrolldate, createdby, 
                        createddate, modifiedby, modifieddate)
VALUES (101, 999, SYSDATE, USER, SYSDATE, USER, SYSDATE);


--test truy vấn ở tầng lưu trữ
SET SERVEROUTPUT ON;
DECLARE
    v_start_time TIMESTAMP;
    v_end_time   TIMESTAMP;
    v_total_cost NUMBER;
BEGIN
    -- Bắt đầu đo thời gian
    v_start_time := SYSTIMESTAMP;

    -- Xử lý logic trực tiếp tại tầng Database
    SELECT SUM(c.Cost)
    INTO v_total_cost
    FROM enrollment e
    JOIN course c ON e.classid = c.courseno;

    -- Kết thúc đo thời gian
    v_end_time := SYSTIMESTAMP;

    DBMS_OUTPUT.PUT_LINE('Tổng học phí: ' || v_total_cost);
    -- In ra chênh lệch thời gian thực thi
    DBMS_OUTPUT.PUT_LINE('Thời gian thực thi (DB Layer): ' || (v_end_time - v_start_time));
END;
/
