--PHIẾU BÀI TẬP 1
--Cấu trúc CSDL 
-- Tạo bảng Hang
CREATE TABLE Hang (
    Mahang VARCHAR2(10) PRIMARY KEY,
    Tenhang VARCHAR2(50),
    Soluong NUMBER(10),
    Giaban NUMBER(15,2)
);

-- Tạo bảng Hoadon
CREATE TABLE Hoadon (
    Mahd VARCHAR2(10) PRIMARY KEY,
    Mahang VARCHAR2(10) REFERENCES Hang(Mahang),
    Soluongban NUMBER(10),
    Ngayban DATE
);

-- Chèn dữ liệu mẫu vào bảng Hang để lát nữa test
INSERT INTO Hang VALUES ('H01', 'Dien thoai Nokia', 50, 2000000);
INSERT INTO Hang VALUES ('H02', 'Dien thoai Samsung', 20, 5000000);
COMMIT;



--Bài 1 – Trigger INSERT trên bảng HOADON
CREATE OR REPLACE TRIGGER trg_Hoadon_Insert
BEFORE INSERT ON Hoadon
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
    v_soluong_ton NUMBER := 0;
BEGIN
    -- 1. Mahang có tồn tại trong bảng HANG không? 
    SELECT COUNT(*) INTO v_dem FROM Hang WHERE Mahang = :NEW.Mahang;
    
    IF v_dem = 0 THEN
        -- Nếu không → đưa ra thông báo lỗi và hủy giao dịch. 
        RAISE_APPLICATION_ERROR(-20001, 'Loi: Ma hang khong ton tai!');
    END IF;

    -- 2. Soluongban <= Soluong tồn kho? 
    SELECT Soluong INTO v_soluong_ton FROM Hang WHERE Mahang = :NEW.Mahang;
        --Nếu không → thông báo lỗi và hủy giao dịch
    IF :NEW.Soluongban > v_soluong_ton THEN
        RAISE_APPLICATION_ERROR(-20002, 'Loi: So luong ban vuot qua so luong ton kho!');
    END IF;

    -- 3. Nếu thỏa mãn → UPDATE: Soluong = Soluong - Soluongban
    UPDATE Hang 
    SET Soluong = Soluong - :NEW.Soluongban
    WHERE Mahang = :NEW.Mahang;
    
END trg_Hoadon_Insert;
/

-- Gọi trigger (test): 
-- 1. Bán quá số lượng tồn (H01 có 50 cái, bán 60 cái -> Sẽ văng ra lỗi đỏ)
INSERT INTO Hoadon VALUES ('HD01', 'H01', 60, SYSDATE);

--2. Bán mã hàng không tồn tại (H99 -> Sẽ văng ra lỗi đỏ)
INSERT INTO Hoadon VALUES ('HD02', 'H99', 5, SYSDATE);

-- 3. Bán hợp lệ (H01 bán 10 cái -> Thành công)
INSERT INTO Hoadon VALUES ('HD03', 'H01', 10, SYSDATE);
COMMIT;

SELECT * FROM Hang;

--Bài 2 – Trigger DELETE trên bảng HOADON 
CREATE OR REPLACE TRIGGER trg_Hoadon_Delete
AFTER DELETE ON Hoadon
FOR EACH ROW
BEGIN
    UPDATE Hang
    SET Soluong = Soluong + :OLD.Soluongban
    WHERE Mahang = :OLD.Mahang;
END trg_Hoadon_Delete;
/

-- Gọi trigger (test): 
-- Xóa hóa đơn vừa tạo ở Test 3 bên trên
DELETE FROM Hoadon WHERE Mahd = 'HD03';
COMMIT;

-- Xem lại bảng Hang, bạn sẽ thấy số lượng H01 tự động tăng trở lại thành 50
SELECT * FROM Hang;


--Bài 3 – Trigger UPDATE trên bảng HOADON
CREATE OR REPLACE TRIGGER trg_Hoadon_Update
BEFORE UPDATE ON Hoadon
FOR EACH ROW
BEGIN
    UPDATE Hang
    SET Soluong = Soluong - (:NEW.Soluongban - :OLD.Soluongban)
    WHERE Mahang = :NEW.Mahang;
END trg_Hoadon_Update;
/

---- Gọi trigger (test): 
-- Tạo lại một hóa đơn hợp lệ (bán 10 cái)
INSERT INTO Hoadon VALUES ('HD04', 'H01', 10, SYSDATE);
COMMIT;
--H01 còn 40 cái
SELECT * FROM Hang;

-- Sửa hóa đơn: mua 15 cái (tăng thêm 5 cái)
UPDATE Hoadon SET Soluongban = 15 WHERE Mahd = 'HD04';
COMMIT;
--H01 tự động trừ thêm 5 cái, chỉ còn 35 cái
SELECT * FROM Hang;


--PHIẾU BÀI TẬP 2
--Cấu trúc CSDL QLBH:
--Bảng MatHang 
CREATE TABLE Mathang ( 
    Mahang VARCHAR2(5) CONSTRAINT pk_mathang PRIMARY KEY, 
    Tenhang VARCHAR2(50) NOT NULL, 
    Soluong NUMBER(10) 
); 

--Bảng Nhatybanhang 
CREATE TABLE Nhatkybanhang ( 
    Stt NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, 
    Ngay DATE, 
    Nguoimua VARCHAR2(50), 
    Mahang VARCHAR2(5) REFERENCES Mathang(Mahang), 
    Soluong NUMBER(10), 
    Giaban NUMBER(15,2) 
); 

-- Dữ liệu mẫu Mathang 
INSERT INTO Mathang VALUES ('1','Hang A', 100); 
INSERT INTO Mathang VALUES ('2','Hang B', 200); 
INSERT INTO Mathang VALUES ('3','Hang C', 150); 
COMMIT;


--a. Trigger trg_nhatkybanhang_insert
CREATE OR REPLACE TRIGGER trg_nhatkybanhang_insert 
AFTER INSERT ON Nhatkybanhang 
FOR EACH ROW 
BEGIN 
    UPDATE Mathang 
    SET Soluong = Soluong - :NEW.Soluong 
    WHERE Mahang = :NEW.Mahang; 
END; 
/

--test 
--Xem số lượng trước khi mua (Mã '1' đang có 100)
SELECT * FROM Mathang WHERE Mahang = '1';

-- Thực hiện mua 10 sản phẩm
INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
VALUES (SYSDATE, 'Khach A', '1', 10, 20000);
COMMIT;

-- Xem lại số lượng (Mã '1' tự động giảm còn 90)
SELECT * FROM Mathang WHERE Mahang = '1';


--b. Trigger trg_nhatkybanhang_update_soluong 
CREATE OR REPLACE TRIGGER trg_nhatkybanhang_update_sl 
AFTER UPDATE OF Soluong ON Nhatkybanhang 
FOR EACH ROW 
BEGIN 
    UPDATE Mathang 
    SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong) 
    WHERE Mahang = :NEW.Mahang; 
END; 
/
--test 
-- Giả sử ở câu a, người mua 'Khach A' có Stt = 1 đã mua 10 cái.
-- Giờ họ đổi ý, muốn mua 15 cái (tăng thêm 5 cái).
UPDATE Nhatkybanhang SET Soluong = 15 WHERE Stt = 1;
COMMIT;

-- Xem lại bảng Mathang, mã '1' sẽ bị trừ thêm 5 cái nữa (còn 85)
SELECT * FROM Mathang WHERE Mahang = '1';

--c. Trigger INSERT có kiểm tra số lượng hợp lệ  
CREATE OR REPLACE TRIGGER trg_nhatky_insert_check
BEFORE INSERT ON Nhatkybanhang 
FOR EACH ROW 
DECLARE
    v_sl_ton NUMBER := 0;
BEGIN 
    SELECT Soluong INTO v_sl_ton FROM Mathang WHERE Mahang = :NEW.Mahang;
    
    IF :NEW.Soluong > v_sl_ton THEN
        RAISE_APPLICATION_ERROR(-20001, 'Loi: So luong ban vuot qua ton kho!'); -- Báo lỗi và hủy 
    ELSE
        UPDATE Mathang SET Soluong = Soluong - :NEW.Soluong WHERE Mahang = :NEW.Mahang; -- Trừ số lượng 
    END IF;
END; 
/

--test
--Cố tình mua 500 cái (vượt tồn kho), hệ thống sẽ báo lỗi đỏ và chặn lại
INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
VALUES (SYSDATE, 'Khach B', '1', 500, 20000);

--d. Trigger UPDATE kiểm soát số dòng (Compound Trigger) 
CREATE OR REPLACE PACKAGE pkg_state AS 
    g_row_count NUMBER := 0; 
END pkg_state; 
/

CREATE OR REPLACE TRIGGER trg_nhatky_update_compound 
FOR UPDATE ON Nhatkybanhang 
COMPOUND TRIGGER 
    BEFORE STATEMENT IS 
    BEGIN 
        pkg_state.g_row_count := 0; 
    END BEFORE STATEMENT; 

    BEFORE EACH ROW IS 
    BEGIN 
        pkg_state.g_row_count := pkg_state.g_row_count + 1; 
        IF pkg_state.g_row_count > 1 THEN 
            RAISE_APPLICATION_ERROR(-20002, 'Loi: Chi duoc cap nhat 1 dong!'); 
        END IF; 
    END BEFORE EACH ROW; 

    AFTER EACH ROW IS
    BEGIN
        UPDATE Mathang 
        SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong) 
        WHERE Mahang = :NEW.Mahang;
    END AFTER EACH ROW;
END trg_nhatky_update_compound; 
/

--test 
-- Thêm nhanh 1 dòng nhật ký nữa để có 2 dòng trong bảng
INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
VALUES (SYSDATE, 'Khach C', '2', 5, 50000);
COMMIT;

--Cố tình chạy UPDATE không có WHERE để tác động nhiều dòng cùng lúc
-- Hệ thống sẽ chặn lại: "Loi: Chi duoc cap nhat 1 dong!"
UPDATE Nhatkybanhang SET Soluong = 20;


--e. Trigger DELETE kiểm soát số dòng 
CREATE OR REPLACE PACKAGE pkg_nhatky_del AS 
    g_row_count NUMBER := 0; 
END pkg_nhatky_del; 
/

-- Chạy Trigger này
CREATE OR REPLACE TRIGGER trg_nhatky_delete_compound 
FOR DELETE ON Nhatkybanhang 
COMPOUND TRIGGER 
    BEFORE STATEMENT IS 
    BEGIN 
        pkg_nhatky_del.g_row_count := 0; 
    END BEFORE STATEMENT; 

    BEFORE EACH ROW IS 
    BEGIN 
        -- Đếm số dòng bị xóa
        pkg_nhatky_del.g_row_count := pkg_nhatky_del.g_row_count + 1; 
        IF pkg_nhatky_del.g_row_count > 1 THEN 
            RAISE_APPLICATION_ERROR(-20001, 'Loi: Chi duoc xoa 1 dong!'); 
        END IF; 
    END BEFORE EACH ROW; 

    AFTER EACH ROW IS
    BEGIN
        -- Cộng lại số lượng vào kho
        UPDATE Mathang 
        SET Soluong = Soluong + :OLD.Soluong 
        WHERE Mahang = :OLD.Mahang;
    END AFTER EACH ROW;
END trg_nhatky_delete_compound; 
/

--test 
-- Giả sử trong bảng Nhatkybanhang của bạn đang có sẵn dữ liệu.
-- TEST HỢP LỆ (Xóa 1 dòng):
DELETE FROM Nhatkybanhang WHERE Stt = 1;
COMMIT;

-- TEST LỖI (Cố tình xóa toàn bộ bảng):
-- Sẽ bị chặn lại bằng thông báo lỗi: "Loi: Chi duoc xoa 1 dong!"
DELETE FROM Nhatkybanhang;


--f. Trigger UPDATE nâng cao – Kiểm tra nhiều điều kiện 
CREATE OR REPLACE TRIGGER trg_nhatky_update_nangcao 
FOR UPDATE ON Nhatkybanhang 
COMPOUND TRIGGER 
    BEFORE STATEMENT IS 
    BEGIN 
        pkg_nhatky_del.g_row_count := 0; -- Tận dụng lại package đếm ở câu e
    END BEFORE STATEMENT; 

    BEFORE EACH ROW IS 
        v_tonkho NUMBER := 0;
    BEGIN 
        pkg_nhatky_del.g_row_count := pkg_nhatky_del.g_row_count + 1; 
        IF pkg_nhatky_del.g_row_count > 1 THEN 
            RAISE_APPLICATION_ERROR(-20001, 'Loi: Chi duoc cap nhat 1 dong!'); 
        END IF; 

        -- Lấy số lượng tồn kho để kiểm tra
        SELECT Soluong INTO v_tonkho FROM Mathang WHERE Mahang = :NEW.Mahang;

        -- Kiểm tra các điều kiện theo đúng đề bài
        IF :NEW.Soluong < v_tonkho THEN
            RAISE_APPLICATION_ERROR(-20002, 'Loi sai cap nhat: So luong cap nhat < ton kho!');
        ELSIF :NEW.Soluong = v_tonkho THEN
            RAISE_APPLICATION_ERROR(-20003, 'Thong bao: Khong can cap nhat (So luong = Ton kho)');
        END IF;
    END BEFORE EACH ROW; 

    AFTER EACH ROW IS
    BEGIN
        -- Ngược lại -> cập nhật giá trị
        UPDATE Mathang 
        SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong) 
        WHERE Mahang = :NEW.Mahang;
    END AFTER EACH ROW;
END; 
/




--g. Thủ tục xóa MATHANG (có tác động 2 bảng) 
CREATE OR REPLACE PROCEDURE sp_xoaMathang (
    p_Mahang IN VARCHAR2
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM Mathang WHERE Mahang = p_Mahang;
    
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma hang khong ton tai!');
    ELSE
        -- Xóa bảng con trước
        DELETE FROM Nhatkybanhang WHERE Mahang = p_Mahang;
        -- Xóa bảng cha sau
        DELETE FROM Mathang WHERE Mahang = p_Mahang;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Xoa mat hang va nhat ky ban hang thanh cong!');
    END IF;
END;
/

--h. Hàm tính tổng tiền theo tên hàng 
CREATE OR REPLACE FUNCTION fn_TongTien (
    p_Tenhang IN VARCHAR2
) RETURN NUMBER AS 
    v_tong NUMBER := 0; 
BEGIN 
    SELECT SUM(nk.Soluong * nk.Giaban) INTO v_tong 
    FROM Nhatkybanhang nk 
    JOIN Mathang mh ON nk.Mahang = mh.Mahang 
    WHERE mh.Tenhang = p_Tenhang; 
    
    -- Dùng NVL để trả về 0 nếu mặt hàng đó chưa bán được cái nào
    RETURN NVL(v_tong, 0); 
END fn_TongTien; 
/

--test
SELECT fn_TongTien('Hang A') AS Tong_Doanh_Thu FROM DUAL;