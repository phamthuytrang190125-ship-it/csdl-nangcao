--Câu 1. Tạo cơ sở dữ liệu
--Bảng Ngân hàng
CREATE TABLE NganHang (
    MaNH NUMBER PRIMARY KEY,
    TenNH VARCHAR2(100)
);

--Bảng Chi nhánh
CREATE TABLE ChiNhanh (
    MaNH NUMBER,
    MaCN VARCHAR2(10) PRIMARY KEY,
    ThanhPhoCN VARCHAR2(50),
    TaiSan NUMBER,
    FOREIGN KEY (MaNH) REFERENCES NganHang(MaNH)
);

--Bảng Khách hàng
CREATE TABLE KhachHang (
    MaKH VARCHAR2(15) PRIMARY KEY,
    TenKH VARCHAR2(100),
    DiaChi VARCHAR2(200)
);

--Bảng Tài khoản vay
CREATE TABLE TaiKhoanVay (
    MaKH VARCHAR2(15),
    MaCN VARCHAR2(10),
    SoTKV VARCHAR2(15) PRIMARY KEY,
    SoTienVay NUMBER,
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    FOREIGN KEY (MaCN) REFERENCES ChiNhanh(MaCN)
);

--Bảng Tài khoản gói
CREATE TABLE TaiKhoanGoi (
    MaKH VARCHAR2(15),
    MaCN VARCHAR2(10),
    SoTKG VARCHAR2(15) PRIMARY KEY,
    SoTienGoi NUMBER,
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    FOREIGN KEY (MaCN) REFERENCES ChiNhanh(MaCN)
);

--Câu 2. Thêm dữ liệu mẫu vào các bảng
--Dữ liệu Ngân hàng
INSERT INTO NganHang (MaNH, TenNH) VALUES (1, 'Ngan Hang Cong Thuong');
INSERT INTO NganHang (MaNH, TenNH) VALUES (2, 'Ngan Hang Ngoai Thuong');
INSERT INTO NganHang (MaNH, TenNH) VALUES (3, 'Ngan Hang Nong Nghiep');
INSERT INTO NganHang (MaNH, TenNH) VALUES (4, 'Ngan Hang A Chau');
INSERT INTO NganHang (MaNH, TenNH) VALUES (5, 'Ngan Hang Thuong Tin');

SELECT * FROM NganHang;


-- Dữ liệu Chi nhánh  
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (1, 'CN01', 'Da Lat', 2000000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (2, 'CN02', 'Nha Trang', 2700000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (3, 'CN03', 'Thanh Hoa', 4500000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (4, 'CN04', 'TP HCM', 6000000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (5, 'CN05', 'Da Nang', 7000000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (1, 'CN11', 'TP HCM', 5000000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (2, 'CN12', 'Hue', 1400000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (3, 'CN13', 'Da Nang', 3600000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (4, 'CN14', 'Ha Noi', 5700000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (1, 'CN21', 'Ha Noi', 3500000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (2, 'CN22', 'Ha Noi', 4500000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (3, 'CN23', 'Da Lat', 2400000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (1, 'CN31', 'Da Nang', 4000000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (2, 'CN32', 'TP HCM', 5600000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (3, 'CN33', 'Can Tho', 5400000000);
INSERT INTO ChiNhanh (MaNH, MaCN, ThanhPhoCN, TaiSan) VALUES (3, 'CN43', 'Nam Dinh', 3600000000);

SELECT * FROM ChiNhanh;


-- Dữ liệu Khách hàng 
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('111222333', 'Ho Thi Thanh Thao', '456 Le Duan, Ha Noi');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('112233445', 'Tran Van Tien', '12 Dien Bien Phu, Q1, TP HCM');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('123123123', 'Phan Thi Quynh Nhu', '54 Hai Ba Trung, Ha Noi');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('123412341', 'Nguyen Van Thao', '34 Tran Phu, TP Nha Trang');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('123456789', 'Nguyen Thi Hoa', '1/4 Hoang Van Thu, Da Lat');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('221133445', 'Nguyen Thi Kim Mai', '4 Tran Binh Trong, Da Lat');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('222111333', 'Do Tien Dong', '123 Tran Phu, Nam Dinh');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('331122445', 'Bui Thi Dong', '345 Tran Hung Dao, Thanh Hoa');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('333111222', 'Tran Dinh Hung', '783 Ly Thuong Kiet, Can Tho');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('441122335', 'Nguyen dinh Cuong', 'P12 Thanh Xuan Nam, Q Thanh Xuan');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('456456456', 'Tran Nam Son', '5 Le Duan, TP Da Nang');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('551122334', 'Tran Thi Khanh Van', '1A Ho Tung Mau, Da Lat');
INSERT INTO KhachHang (MaKH, TenKH, DiaChi) VALUES ('987654321', 'Ho Thanh Son', '209 Tran Hung Dao, Q5, TP HCM');

SELECT * FROM KhachHang;

--Dữ liệu TaiKhoanGoi
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('123123123', 'CN01', '00001A', 10000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('123456789', 'CN01', '00001C', 127000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('221133445', 'CN02', '00002A', 12500000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('456456456', 'CN03', '00003H', 123000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('222111333', 'CN05', '00005A', 1200000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('987654321', 'CN05', '00005D', 345000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('123412341', 'CN05', '00005N', 45000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('331122445', 'CN13', '00003A', 27000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('551122334', 'CN14', '00004D', 560000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('123456789', 'CN14', '00004P', 35400000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('123412341', 'CN21', '00001B', 67000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('222111333', 'CN22', '00002G', 56000000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('987654321', 'CN23', '00004F', 4500000);
INSERT INTO TaiKhoanGoi (MaKH, MaCN, SoTKG, SoTienGoi) VALUES ('333111222', 'CN33', '00003D', 47000000);

SELECT * FROM TaiKhoanGoi;

--Dữ liệu TaiKhoanVay
INSERT INTO TaiKhoanVay (MaKH, MaCN, SoTKV, SoTienVay) VALUES ('111222333', 'CN01', '10001A', 10000000);
INSERT INTO TaiKhoanVay (MaKH, MaCN, SoTKV, SoTienVay) VALUES ('333111222', 'CN02', '10002A', 6000000);
INSERT INTO TaiKhoanVay (MaKH, MaCN, SoTKV, SoTienVay) VALUES ('551122334', 'CN04', '10004A', 20000000);
INSERT INTO TaiKhoanVay (MaKH, MaCN, SoTKV, SoTienVay) VALUES ('221133445', 'CN05', '10005G', 15000000);
INSERT INTO TaiKhoanVay (MaKH, MaCN, SoTKV, SoTienVay) VALUES ('987654321', 'CN11', '10001D', 45000000);
INSERT INTO TaiKhoanVay (MaKH, MaCN, SoTKV, SoTienVay) VALUES ('112233445', 'CN12', '10002D', 12000000);
INSERT INTO TaiKhoanVay (MaKH, MaCN, SoTKV, SoTienVay) VALUES ('441122335', 'CN13', '10003F', 5500000);
INSERT INTO TaiKhoanVay (MaKH, MaCN, SoTKV, SoTienVay) VALUES ('123123123', 'CN14', '10005A', 12500000);

SELECT * FROM TaiKhoanVay;

COMMIT;

--Thực hiện các câu truy vấn trên cơ sở dữ liệu NganHang
--1. Tìm tên tất cả các ngân hàng có chi nhánh ngân hàng ở thanh phố “Da Lat”.
SELECT DISTINCT nh.TenNH 
FROM NganHang nh JOIN ChiNhanh cn ON nh.MaNH = cn.MaNH 
WHERE cn.ThanhPhoCN = 'Da Lat';

--2. Tìm tất cả những thành phố mà có chi nhánh của ngân hàng công thương.
SELECT DISTINCT cn.ThanhPhoCN 
FROM ChiNhanh cn JOIN NganHang nh ON cn.MaNH = nh.MaNH 
WHERE nh.TenNH = 'Ngan Hang Cong Thuong';

--3. Tìm thông tin về tất cả các chi nhánh của ngân hàng công thương có địa điểm ở TPHCM.
SELECT cn.* FROM ChiNhanh cn JOIN NganHang nh ON cn.MaNH = nh.MaNH 
WHERE nh.TenNH = 'Ngan Hang Cong Thuong' AND cn.ThanhPhoCN = 'TP HCM';

--4. Xuất thông tin từng ngân hàng và chi nhánh của nó.
SELECT nh.TenNH, cn.* FROM NganHang nh LEFT JOIN ChiNhanh cn ON nh.MaNH = cn.MaNH;

--5. Tìm khách hàng mà địa chỉ của họ ở 'Ha Noi'.
SELECT * FROM KhachHang WHERE DiaChi LIKE '%Ha Noi%';

--6. Tìm các khách hàng có tên Son.
SELECT * FROM KhachHang WHERE TenKH LIKE '% Son';

--7. Tìm các khách hàng mà địa chỉ của họ ở đường "Tran Hung Dao".
SELECT * FROM KhachHang WHERE DiaChi LIKE '%Tran Hung Dao%';

--8. Tìm các khách hàng có tên "Thao".
SELECT * FROM KhachHang WHERE TenKH LIKE '% Thao';

--9. Tìm khách hàng có mã số bắt đầu là '11' và ở TP HCM.
SELECT * FROM KhachHang 
WHERE MaKH LIKE '11%' AND DiaChi LIKE '%TP HCM%';

--10. Xuất thông tin về tên ngân hàng, thành phố chi nhánh và tài sản theo thứ tự tăng
--của tài sản của chi nhánh, nếu tài sản trùng nhau thì sắp tăng theo thành phố chi nhánh.
SELECT nh.TenNH, cn.ThanhPhoCN, cn.TaiSan 
FROM NganHang nh JOIN ChiNhanh cn ON nh.MaNH = cn.MaNH 
ORDER BY cn.TaiSan ASC, cn.ThanhPhoCN ASC;


--11. Tìm thông tin tất cả những thông tin về ngân hàng và chi nhánh ngân hàng mà tài
--sản 3000000000 < tài sản < 5000000000.
SELECT nh.TenNH, cn.* FROM NganHang nh JOIN ChiNhanh cn ON nh.MaNH = cn.MaNH 
WHERE cn.TaiSan > 3000000000 AND cn.TaiSan < 5000000000;

--12. Cho biết tài sản trung bình chi nhánh của từng ngân hàng.
SELECT MaNH, AVG(TaiSan) as TaiSan_TrungBinh 
FROM ChiNhanh GROUP BY MaNH;

--13. Tìm thông tin của khách hàng có tài khoản vay tại ngân hàng công thương và có
--tên là 'Thao'.
SELECT DISTINCT kh.* FROM KhachHang kh
JOIN TaiKhoanVay tkv ON kh.MaKH = tkv.MaKH
JOIN ChiNhanh cn ON tkv.MaCN = cn.MaCN
JOIN NganHang nh ON cn.MaNH = nh.MaNH
WHERE (kh.TenKH LIKE '% Thao' OR kh.TenKH = 'Thao') 
  AND nh.TenNH = 'Ngan Hang Cong Thuong';

--14. Xuất thông tin về tên ngân hàng và tổng tài sản của các ngân hàng.
SELECT nh.TenNH, SUM(cn.TaiSan) as Tong_Tai_San 
FROM NganHang nh JOIN ChiNhanh cn ON nh.MaNH = cn.MaNH 
GROUP BY nh.TenNH;

--15. Tìm MaCN và TaiSan của chi nhánh có tài sản lớn nhất.
SELECT MaCN, TaiSan FROM ChiNhanh 
WHERE TaiSan = (SELECT MAX(TaiSan) FROM ChiNhanh);

--16. Liệt kê tất cả những những khách hành có tài khoản gởi tại chi nhánh ngân hàng
--“A Chau”.
SELECT kh.* FROM KhachHang kh 
JOIN TaiKhoanGoi tkg ON kh.MaKH = tkg.MaKH 
JOIN ChiNhanh cn ON tkg.MaCN = cn.MaCN 
JOIN NganHang nh ON cn.MaNH = nh.MaNH 
WHERE nh.TenNH = 'Ngan Hang A Chau';

--17. Tìm tất cả các số tài khoản vay thực hiện tại chi nhánh của ngân hàng ngoại
--thương mà số tiền vay > 1200000.
SELECT tkv.SoTKV FROM TaiKhoanVay tkv 
JOIN ChiNhanh cn ON tkv.MaCN = cn.MaCN 
JOIN NganHang nh ON cn.MaNH = nh.MaNH 
WHERE nh.TenNH = 'Ngan Hang Ngoai Thuong' AND tkv.SoTienVay > 1200000;

--18. Tính tổng số tiền mà mỗi chi nhánh ngân hàng đang được khách hàng gởi.
SELECT MaCN, SUM(SoTienGoi) as Tong_Tien_Gui 
FROM TaiKhoanGoi GROUP BY MaCN;

--19. Xuất thông tin về tài khoản vay và tài khoản gởi hiện có của tất cả các khách hàng
--có tên là 'Son'.
SELECT kh.TenKH, tkv.SoTKV, tkv.SoTienVay, tkg.SoTKG, tkg.SoTienGoi 
FROM KhachHang kh 
LEFT JOIN TaiKhoanVay tkv ON kh.MaKH = tkv.MaKH 
LEFT JOIN TaiKhoanGoi tkg ON kh.MaKH = tkg.MaKH 
WHERE kh.TenKH LIKE '% Son';

--20. Tìm thông tin về khách hàng có tổng số tiền vay tại tất cả các ngân hàng >30000000.
SELECT MaKH, SUM(SoTienVay) as Tong_Vay 
FROM TaiKhoanVay 
GROUP BY MaKH HAVING SUM(SoTienVay) > 30000000;



