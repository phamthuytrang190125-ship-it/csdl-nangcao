--D.1 & 2. Thủ tục sp_them_nhan_vien1 (Kiểm tra nhiều điều kiện và trả về OUT)
CREATE OR REPLACE PROCEDURE sp_them_nhan_vien1 (
    p_MaNV IN VARCHAR2, 
    p_MaCV IN VARCHAR2, 
    p_TenNV IN VARCHAR2, 
    p_NgaySinh IN DATE, 
    p_LuongCB IN NUMBER, 
    p_NgayCong IN NUMBER, 
    p_PhuCap IN NUMBER,
    p_kq OUT NUMBER -- Tham so OUT de tra ket qua
) AS 
    v_dem_nv NUMBER := 0;
    v_dem_cv NUMBER := 0;
BEGIN
    -- Kiem tra MaNV da ton tai chua
    SELECT COUNT(*) INTO v_dem_nv FROM tblNhanVien WHERE MaNV = p_MaNV;
    -- Kiem tra MaCV co ton tai trong bang ChucVu chua
    SELECT COUNT(*) INTO v_dem_cv FROM tblChucVu WHERE MaCV = p_MaCV;

    IF v_dem_nv > 0 THEN
        p_kq := 0; -- Neu MaNV da ton tai tra ra 0
    ELSIF v_dem_cv = 0 THEN
        p_kq := 1; -- Neu MaCV chua ton tai tra ra 1
    ELSE
        -- Cho phep chen ban ghi
        INSERT INTO tblNhanVien(MaNV, MaCV, TenNV, NgaySinh, LuongCanBan, NgayCong, PhuCap) 
        VALUES (p_MaNV, p_MaCV, p_TenNV, p_NgaySinh, p_LuongCB, p_NgayCong, p_PhuCap);
        COMMIT;
        p_kq := 2; -- Tra ra 2 sau khi chen thanh cong
    END IF;
END sp_them_nhan_vien1;
/


--D.3.Thủ tục cập nhật NgaySinh cho nhân viên 
CREATE OR REPLACE PROCEDURE sp_capnhat_ngaysinh (
    p_MaNV IN VARCHAR2, 
    p_NgaySinh IN DATE,
    p_kq OUT NUMBER
) AS 
    v_dem NUMBER := 0;
BEGIN
    -- Kiem tra xem co tim thay ban ghi can cap nhat khong
    SELECT COUNT(*) INTO v_dem FROM tblNhanVien WHERE MaNV = p_MaNV;

    IF v_dem = 0 THEN
        p_kq := 0; -- Neu khong tim thay ban ghi can cap nhat tra ra 0
    ELSE
        -- Nguoc lai cho phep cap nhat
        UPDATE tblNhanVien 
        SET NgaySinh = p_NgaySinh 
        WHERE MaNV = p_MaNV;
        COMMIT;
        p_kq := 1; -- Quy uoc tra ve 1 la thanh cong
    END IF;
END sp_capnhat_ngaysinh;
/