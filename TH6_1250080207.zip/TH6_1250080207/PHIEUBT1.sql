--Phiếu bài tập 1
--Bài tập 1
CREATE TABLE KHOA (
    Makhoa VARCHAR2(50) PRIMARY KEY,
    Tenkhoa VARCHAR2(100),
    Dienthoai VARCHAR2(20)
);

CREATE OR REPLACE PROCEDURE SP_Them_Khoa (
    p_makhoa IN VARCHAR2, 
    p_tenkhoa IN VARCHAR2, 
    p_dienthoai IN VARCHAR2
) AS 
    v_dem NUMBER := 0; 
BEGIN 
    SELECT COUNT(*) INTO v_dem FROM KHOA WHERE Tenkhoa = p_tenkhoa;
    
    IF v_dem > 0 THEN 
        DBMS_OUTPUT.PUT_LINE('Ten khoa da ton tai, vui long nhap ten khac!'); 
    ELSE 
        INSERT INTO KHOA(Makhoa, Tenkhoa, Dienthoai) VALUES (p_makhoa, p_tenkhoa, p_dienthoai);
        COMMIT; 
        DBMS_OUTPUT.PUT_LINE('Them khoa thanh cong!');
    END IF; 
END SP_Them_Khoa; 
/

--Bài tập 2
CREATE TABLE LOP (
    Malop VARCHAR2(50) PRIMARY KEY,
    Tenlop VARCHAR2(100),
    Khoa VARCHAR2(50),
    Hedt VARCHAR2(50),
    Namnhaphoc NUMBER,
    Makhoa VARCHAR2(50) REFERENCES KHOA(Makhoa) -- Tạo khóa ngoại liên kết với bảng KHOA
);

CREATE OR REPLACE PROCEDURE SP_Them_Lop (
    p_malop IN VARCHAR2, 
    p_tenlop IN VARCHAR2, 
    p_khoa IN VARCHAR2, 
    p_hedt IN VARCHAR2, 
    p_namnhaphoc IN NUMBER, 
    p_makhoa IN VARCHAR2
) AS 
    v_dem_lop NUMBER := 0; 
    v_dem_khoa NUMBER := 0; 
BEGIN 
    -- Kiểm tra xem tên lớp đã có trước đó chưa 
    SELECT COUNT(*) INTO v_dem_lop FROM LOP WHERE Tenlop = p_tenlop;
    
    -- Kiểm tra xem Makhoa có trong bảng KHOA hay không 
    SELECT COUNT(*) INTO v_dem_khoa FROM KHOA WHERE Makhoa = p_makhoa;
    
    IF v_dem_lop > 0 THEN 
        DBMS_OUTPUT.PUT_LINE('Thong bao: Ten lop nay da ton tai!'); 
    ELSIF v_dem_khoa = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Thong bao: Ma khoa khong ton tai trong bang KHOA!'); 
    ELSE 
        -- Nếu đầy đủ thông tin thì cho nhập 
        INSERT INTO LOP(Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa) 
        VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);
        
        COMMIT; -- Lưu thay đổi 
        DBMS_OUTPUT.PUT_LINE('Thong bao: Them lop thanh cong!');
    END IF; 
END SP_Them_Lop; 
/

--Bài tập 3
CREATE OR REPLACE PROCEDURE SP_Them_Khoa_Out (
    p_makhoa IN VARCHAR2, 
    p_tenkhoa IN VARCHAR2, 
    p_dienthoai IN VARCHAR2,
    p_kq OUT NUMBER -- Tham số OUT để trả về kết quả
) AS 
    v_dem NUMBER := 0; 
BEGIN 
    -- Kiểm tra tên khoa
    SELECT COUNT(*) INTO v_dem FROM KHOA WHERE Tenkhoa = p_tenkhoa;
    
    IF v_dem > 0 THEN 
        p_kq := 0; -- Trả về 0 nếu đã tồn tại
    ELSE 
        INSERT INTO KHOA(Makhoa, Tenkhoa, Dienthoai) VALUES (p_makhoa, p_tenkhoa, p_dienthoai);
        COMMIT; -- Lưu thay đổi
        p_kq := 1; -- Tự quy ước trả về 1 nếu thêm thành công
    END IF; 
END SP_Them_Khoa_Out; 
/

--test 2 TH
SET SERVEROUTPUT ON;

DECLARE 
    v_ketqua NUMBER;
BEGIN 
    -- Trường hợp 1: Thêm Khoa mới tinh
    SP_Them_Khoa_Out('K05', 'Ngon ngu Anh', '0112233445', v_ketqua);
    DBMS_OUTPUT.PUT_LINE('Ket qua them K05 (1 la thanh cong): ' || v_ketqua);
    
    -- Trường hợp 2: Cố tình thêm Khoa trùng tên 'Ngon ngu Anh'
    SP_Them_Khoa_Out('K06', 'Ngon ngu Anh', '0998877665', v_ketqua);
    DBMS_OUTPUT.PUT_LINE('Ket qua them K06 (0 la that bai): ' || v_ketqua);
END; 
/

--Bài tập 4
--Code tạo thủ tục SP_Them_Lop_Out
CREATE OR REPLACE PROCEDURE SP_Them_Lop_Out (
    p_malop IN VARCHAR2, 
    p_tenlop IN VARCHAR2, 
    p_khoa IN VARCHAR2, 
    p_hedt IN VARCHAR2, 
    p_namnhaphoc IN NUMBER, 
    p_makhoa IN VARCHAR2,
    p_kq OUT NUMBER
) AS 
    v_dem_lop NUMBER := 0;
    v_dem_khoa NUMBER := 0;
BEGIN 
    -- Đếm xem tên lớp đã tồn tại chưa
    SELECT COUNT(*) INTO v_dem_lop FROM LOP WHERE Tenlop = p_tenlop;
    -- Đếm xem mã khoa có tồn tại không
    SELECT COUNT(*) INTO v_dem_khoa FROM KHOA WHERE Makhoa = p_makhoa;
    
    IF v_dem_lop > 0 THEN 
        p_kq := 0; -- Trả về 0 nếu tên lớp đã có
    ELSIF v_dem_khoa = 0 THEN
        p_kq := 1; -- Trả về 1 nếu mã khoa không tồn tại
    ELSE 
        INSERT INTO LOP(Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa) 
        VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);
        COMMIT;
        p_kq := 2; -- Trả về 2 nếu nhập thành công
    END IF; 
END SP_Them_Lop_Out; 
/

--Test các TH
SET SERVEROUTPUT ON;

DECLARE 
    v_ketqua NUMBER;
BEGIN 
    -- (Giả sử bạn đã có Khoa 'K01' từ các bước trước)
    -- Trường hợp 1: Nhập thành công (Sẽ in ra 2)
    SP_Them_Lop_Out('L10', 'Ngon Ngu Anh K60', 'K60', 'Dai hoc', 2023, 'K01', v_ketqua);
    DBMS_OUTPUT.PUT_LINE('Ket qua them lop moi: ' || v_ketqua);
    
    -- Trường hợp 2: Trùng tên lớp (Sẽ in ra 0)
    SP_Them_Lop_Out('L11', 'Ngon Ngu Anh K60', 'K60', 'Dai hoc', 2023, 'K01', v_ketqua);
    DBMS_OUTPUT.PUT_LINE('Ket qua them lop trung ten: ' || v_ketqua);

    -- Trường hợp 3: Sai mã khoa (Sẽ in ra 1)
    SP_Them_Lop_Out('L12', 'Ngon Ngu Phap K60', 'K60', 'Dai hoc', 2023, 'K99', v_ketqua);
    DBMS_OUTPUT.PUT_LINE('Ket qua sai ma khoa: ' || v_ketqua);
END; 
/






