-- B. Tạo Bảng Chức vụ 
CREATE TABLE tblChucVu (
    MaCV VARCHAR2(50) PRIMARY KEY,
    TenCV VARCHAR2(100)
);

-- B. Tạo Bảng Nhân viên 
CREATE TABLE tblNhanVien (
    MaNV VARCHAR2(50) PRIMARY KEY, 
    MaCV VARCHAR2(50) REFERENCES tblChucVu(MaCV), 
    TenNV VARCHAR2(100), 
    NgaySinh DATE, 
    LuongCanBan NUMBER, 
    NgayCong NUMBER, 
    PhuCap NUMBER 
);

-- C. Chèn 4 chức vụ vào tblChucVu 
INSERT INTO tblChucVu VALUES ('CV01', 'Giam doc');
INSERT INTO tblChucVu VALUES ('CV02', 'Pho Giam doc');
INSERT INTO tblChucVu VALUES ('CV03', 'Truong phong');
INSERT INTO tblChucVu VALUES ('CV04', 'Nhan vien');

-- C. Chèn 3 nhân viên vào tblNhanVien 
INSERT INTO tblNhanVien VALUES ('NV01', 'CV01', 'Nguyen Van A', TO_DATE('15/06/1990', 'DD/MM/YYYY'), 100000, 22, 500000);
INSERT INTO tblNhanVien VALUES ('NV02', 'CV03', 'Tran Thi B', TO_DATE('20/10/1995', 'DD/MM/YYYY'), 80000, 24, 300000);
INSERT INTO tblNhanVien VALUES ('NV03', 'CV04', 'Le Van C', TO_DATE('05/02/1998', 'DD/MM/YYYY'), 50000, 20, 100000);

COMMIT;

--D.a.Thủ tục SP_Them_Nhan_Vien
CREATE OR REPLACE PROCEDURE SP_Them_Nhan_Vien (
    p_MaNV IN VARCHAR2, p_MaCV IN VARCHAR2, p_TenNV IN VARCHAR2, 
    p_NgaySinh IN DATE, p_LuongCanBan IN NUMBER, 
    p_NgayCong IN NUMBER, p_PhuCap IN NUMBER
) AS 
    v_dem NUMBER := 0; 
BEGIN
    -- Kiểm tra MaCV có tồn tại không 
    SELECT COUNT(*) INTO v_dem FROM tblChucVu WHERE MaCV = p_MaCV; 
    
    IF v_dem > 0 THEN 
        -- Thỏa mãn thì thêm nhân viên 
        INSERT INTO tblNhanVien VALUES (p_MaNV, p_MaCV, p_TenNV, p_NgaySinh, p_LuongCanBan, p_NgayCong, p_PhuCap);
        COMMIT; 
        DBMS_OUTPUT.PUT_LINE('Them nhan vien thanh cong!'); 
    ELSE
        -- Không thì đưa ra thông báo [cite: 59]
        DBMS_OUTPUT.PUT_LINE('Loi: Ma chuc vu khong ton tai!'); 
    END IF; 
END SP_Them_Nhan_Vien;
/

--D.b. Thủ tục SP_CapNhat_Nhan_Vien
CREATE OR REPLACE PROCEDURE SP_CapNhat_Nhan_Vien (
    p_MaNV IN VARCHAR2, p_MaCV IN VARCHAR2, p_TenNV IN VARCHAR2, 
    p_NgaySinh IN DATE, p_LuongCanBan IN NUMBER, 
    p_NgayCong IN NUMBER, p_PhuCap IN NUMBER
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM tblChucVu WHERE MaCV = p_MaCV; 
    
    IF v_dem > 0 THEN
        -- Thực hiện UPDATE (không cập nhật MaNV) 
        UPDATE tblNhanVien 
        SET MaCV = p_MaCV, TenNV = p_TenNV, NgaySinh = p_NgaySinh, 
            LuongCanBan = p_LuongCanBan, NgayCong = p_NgayCong, PhuCap = p_PhuCap
        WHERE MaNV = p_MaNV;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Cap nhat thong tin nhan vien thanh cong!');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Loi: Ma chuc vu moi khong ton tai, huy cap nhat!'); 
    END IF;
END SP_CapNhat_Nhan_Vien;
/

--D.c. Thủ tục SP_LuongLN
CREATE OR REPLACE PROCEDURE SP_LuongLN 
AS
    v_luong NUMBER;
BEGIN
    -- Tính và hiển thị lương cho từng nhân viên 
    FOR rec IN (SELECT TenNV, LuongCanBan, NgayCong, PhuCap FROM tblNhanVien) LOOP
        -- Tính toán theo công thức Luong = LuongCanBan × NgayCong + PhuCap 
        v_luong := rec.LuongCanBan * rec.NgayCong + rec.PhuCap;
        DBMS_OUTPUT.PUT_LINE('Nhan vien: ' || rec.TenNV || ' - Tong luong: ' || v_luong);
    END LOOP;
END SP_LuongLN;
/